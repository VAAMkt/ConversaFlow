import React from 'react';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Crown, Flame, HeartHandshake as Handshake, Target, CheckCircle, Mail, Phone, Globe, ArrowRight } from 'lucide-react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
const fadeIn = {
  hidden: {
    opacity: 0,
    y: 20
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6
    }
  }
};
const TalentLandingPage = () => {
  const values = [{
    icon: <Crown className="h-10 w-10 text-yellow-400" />,
    title: "Cumplimos la palabra",
    description: "Nuestra palabra es ley. La confianza es la base de nuestro reino."
  }, {
    icon: <Flame className="h-10 w-10 text-red-500" />,
    title: "Mejoramos cada día",
    description: "La complacencia no tiene lugar aquí. Siempre buscamos la excelencia."
  }, {
    icon: <Target className="h-10 w-10 text-yellow-400" />,
    title: "Servimos con actitud",
    description: "Cada interacción es una oportunidad para demostrar nuestra grandeza."
  }, {
    icon: <Handshake className="h-10 w-10 text-red-500" />,
    title: "Impactamos positivamente",
    description: "Dejamos una huella positiva en nuestro equipo, clientes y comunidad."
  }];
  const testimonials = [{
    name: "Brayan Solarte",
    role: "Líder Coordinador",
    text: "Empecé de domiciliario y hoy lidero el equipo de lideres de punto. KINGPAPA no solo me dio un trabajo, me dio una carrera y una familia. Aquí, si tienes ganas, el cielo es el límite. 🔥"
  }, {
    name: "Carlos Vélez",
    role: "Coordinador de Operaciones",
    text: "Lo que más valoro es la cultura de crecimiento. La empresa invierte en ti, te forma y te da herramientas para que conquistes tus metas. Es un ambiente exigente pero muy gratificante. 💪"
  }, {
    name: "Mariana Ríos",
    role: "Vendedora",
    text: "¡La energía aquí es increíble! Todos los días aprendo algo nuevo y me siento parte de algo grande. Servir a nuestros clientes y verlos felices con nuestras salchipapas no tiene precio. 👑"
  }];
  const growthPath = ["Domiciliario", "Cocinero", "Vendedor", "Cajero", "Líder de punto", "Líder Coordinador", "Líder de Operaciones"];
  const benefits = ["Formación continua", "Bonos por resultados", "Oportunidades de ascenso", "Reconocimientos", "Programas de bienestar"];
  return <HelmetProvider>
      <div className="bg-black text-white font-sans overflow-x-hidden">
        <Helmet>
          <title>El Reino del Talento KINGPAPA 👑 | Únete a la familia del sabor</title>
          <meta name="description" content="Únete al Reino del Talento KINGPAPA. Crece, aprende y conquista tu lugar en la cadena de salchipapas premium más grande de Colombia." />
          <meta name="keywords" content="trabajo kingpapa, empleo restaurante, cultura BIC, vacantes Colombia, talento kingpapa" />
        </Helmet>

        {/* Hero Section */}
        <motion.section className="relative min-h-screen flex items-center justify-center text-center p-4 overflow-hidden" variants={fadeIn} initial="hidden" animate="visible">
          <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
          <img className="absolute inset-0 w-full h-full object-cover" alt="Equipo de KINGPAPA celebrando en un ambiente de trabajo energético" src="https://horizons-cdn.hostinger.com/4de2753a-31fe-4ced-8748-b4eae17cc35f/1000204978-01-980x551-1BSbL.jpeg" />
          <div className="relative z-20 max-w-4xl mx-auto">
            <motion.h1 className="text-5xl md:text-7xl font-extrabold uppercase tracking-tighter text-shadow-gold" style={{
            textShadow: '0 0 10px #fde047, 0 0 20px #fde047'
          }} variants={fadeIn}>
              Aquí no se trabaja, <span className="text-yellow-400">se conquista.</span>
            </motion.h1>
            <motion.p className="mt-6 text-lg md:text-xl max-w-2xl mx-auto text-stone-200" variants={fadeIn}>
              Únete a la cadena de salchipapas premium más grande de Colombia. En KINGPAPA buscamos personas con actitud, ganas de crecer y pasión por servir. Si tienes hambre de aprender y sueñas con ser parte de un equipo que hace historia, este es tu lugar.
            </motion.p>
            <motion.div className="mt-10" variants={fadeIn}>
              <a href="https://kingpapa.online/postula" data-testid="cta-postulate-hero" aria-label="Postúlate ahora" role="button" className="inline-block bg-yellow-400 text-black font-bold text-lg px-10 py-6 rounded-lg uppercase tracking-wider hover:bg-yellow-300 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-yellow-400/30 focus:outline-none focus:ring-4 focus:ring-yellow-300">
                Postúlate ahora 👇
              </a>
            </motion.div>
          </div>
        </motion.section>

        {/* Purpose Section */}
        <section className="py-20 px-4 bg-stone-950">
          <div className="max-w-5xl mx-auto text-center">
            <motion.h2 className="text-4xl md:text-5xl font-bold text-yellow-400 mb-6" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              Por qué existe el Reino del Talento
            </motion.h2>
            <motion.p className="text-lg text-stone-300 mb-10" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.2
          }}>En KINGPAPA creemos que el trabajo solo vale si te hace crecer. Por eso creamos El Reino del Talento, un espacio para los que quieren más que un empleo: quieren propósito, progreso y pertenecer a algo grande. </motion.p>
            <motion.div className="bg-black border-2 border-yellow-400 rounded-xl p-8 shadow-2xl shadow-yellow-400/10" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.4
          }}>
              <p className="text-xl md:text-2xl font-semibold italic text-white">“Somos una empresa BIC: creemos que la rentabilidad y el impacto social no compiten, se multiplican.”</p>
            </motion.div>
          </div>
        </section>

        {/* Culture Section */}
        <section className="py-20 px-4">
          <div className="max-w-6xl mx-auto text-center">
            <motion.h2 className="text-4xl md:text-5xl font-bold mb-12" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              Nuestra cultura es nuestra <span className="text-yellow-400">corona.</span> 👑
            </motion.h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
              {values.map((value, index) => <motion.div key={index} variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
              once: true,
              delay: index * 0.1
            }}>
                  <Card className="bg-stone-900 border-stone-800 text-center p-6 h-full hover:border-yellow-400 hover:-translate-y-2 transition-all duration-300">
                    <CardContent className="flex flex-col items-center justify-start pt-6">
                      {value.icon}
                      <h3 className="text-xl font-bold mt-4 mb-2 text-white">{value.title}</h3>
                      <p className="text-stone-400">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>)}
            </div>
            
            <motion.div variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              <Carousel className="w-full max-w-2xl mx-auto">
                <CarouselContent>
                  {testimonials.map((testimonial, index) => <CarouselItem key={index}>
                      <div className="p-1">
                        <Card className="bg-stone-900 border-stone-800">
                          <CardContent className="flex flex-col items-center justify-center p-8 text-center">
                            <p className="text-lg italic text-stone-300 mb-4">"{testimonial.text}"</p>
                            <h4 className="font-bold text-yellow-400">{testimonial.name}</h4>
                            <p className="text-sm text-stone-500">{testimonial.role}</p>
                          </CardContent>
                        </Card>
                      </div>
                    </CarouselItem>)}
                </CarouselContent>
                <CarouselPrevious className="text-white bg-stone-800 hover:bg-yellow-400 hover:text-black border-stone-700" />
                <CarouselNext className="text-white bg-stone-800 hover:bg-yellow-400 hover:text-black border-stone-700" />
              </Carousel>
            </motion.div>
          </div>
        </section>

        {/* Growth Section */}
        <section className="py-20 px-4 bg-stone-950">
          <div className="max-w-6xl mx-auto text-center">
            <motion.h2 className="text-4xl md:text-5xl font-bold text-yellow-400 mb-6" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              Oportunidades Reales
            </motion.h2>
            <motion.p className="text-lg text-stone-300 max-w-3xl mx-auto mb-12" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.2
          }}>
              En KINGPAPA apostamos por la gente. Cada puesto es una puerta a nuevas oportunidades. Si das resultados, te enseñamos a liderar; si lideras, te ayudamos a multiplicar.
            </motion.p>
            
            <motion.div className="mb-12" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.4
          }}>
              <h3 className="text-2xl font-bold mb-6">Tu Camino de Conquista</h3>
              <div className="flex flex-wrap items-center justify-center gap-2 md:gap-4">
                {growthPath.map((role, index) => <React.Fragment key={role}>
                    <div className="bg-stone-800 text-yellow-400 font-bold py-2 px-4 rounded-lg text-sm md:text-base">
                      {role}
                    </div>
                    {index < growthPath.length - 1 && <ArrowRight className="text-stone-600 hidden md:block" />}
                  </React.Fragment>)}
              </div>
              <p className="mt-6 text-stone-400 max-w-2xl mx-auto">
                También puedes contribuir desde el administrativo en cualquiera de los 5 procesos: Talento Humano, Operaciones, Contabilidad, Mercadeo y Estrategia.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.6
          }}>
              <h3 className="text-2xl font-bold mb-6">Beneficios al ser parte del REINO</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 max-w-4xl mx-auto">
                {benefits.map(benefit => <div key={benefit} className="flex items-center justify-center bg-stone-900 p-4 rounded-lg gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="text-stone-300 text-sm">{benefit}</span>
                  </div>)}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <motion.h2 className="text-4xl md:text-5xl font-bold text-center mb-12" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              Tu camino para entrar al <span className="text-yellow-400">Reino</span>
            </motion.h2>
            <ol className="space-y-8">
              {[{
              icon: "1️⃣",
              text: "Postúlate en",
              link: "https://kingpapa.online/postula"
            }, {
              icon: "⚙️",
              text: "Nuestra IA analiza tu perfil"
            }, {
              icon: "📲",
              text: "Si haces match, te contactamos desde talentohumanokingpapa@gmail.com o WhatsApp +57 316 882 5477"
            }, {
              icon: "👑",
              text: "Participas en tu entrevista y te damos tu bienvenida oficial"
            }].map((step, index) => <motion.li key={index} className="flex items-start gap-4" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
              once: true,
              delay: index * 0.15
            }}>
                  <span className="text-3xl">{step.icon}</span>
                  <p className="text-lg text-stone-300 mt-1">
                    {step.text} {step.link && <a href={step.link} className="text-yellow-400 font-bold hover:underline">{step.link.replace('https://', '')}</a>}
                  </p>
                </motion.li>)}
            </ol>
            <motion.div className="mt-12 text-center bg-stone-900 border border-stone-800 rounded-xl p-6" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.6
          }}>
              <p className="text-xl font-semibold italic text-white">
                “El proceso es rápido, transparente y humano. Porque en KINGPAPA el talento sí importa.”
              </p>
            </motion.div>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="relative py-24 px-4 text-center bg-stone-950">
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black"></div>
          <img className="absolute inset-0 w-full h-full object-cover opacity-20" alt="Luces doradas y rojas abstractas" src="https://images.unsplash.com/photo-1573582231192-d964831f9f77" />
          <div className="relative z-10 max-w-3xl mx-auto">
            <motion.h2 className="text-4xl md:text-5xl font-extrabold uppercase mb-4" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              ¿Listo para conquistar tu lugar?
            </motion.h2>
            <motion.p className="text-lg text-stone-300 mb-10" variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.2
          }}>
              Si crees que tienes la energía, la actitud y las ganas de crecer, este es tu momento. Entra al Reino del Talento y demuestra de qué estás hecho.
            </motion.p>
            <motion.div variants={fadeIn} initial="hidden" whileInView="visible" viewport={{
            once: true,
            delay: 0.4
          }}>
              <a href="https://kingpapa.online/postula" data-testid="cta-postulate-final" aria-label="Quiero ser parte del Reino" role="button" className="inline-block bg-red-600 text-white font-bold text-xl px-12 py-8 rounded-lg uppercase tracking-wider hover:bg-red-500 transition-all duration-300 transform hover:scale-105 shadow-lg shadow-red-500/40 focus:outline-none focus:ring-4 focus:ring-red-500">
                👉 Quiero ser parte del Reino
              </a>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-black border-t border-stone-800 py-12 px-4">
          <div className="max-w-6xl mx-auto text-center text-stone-500">
            <div className="flex justify-center items-center gap-6 md:gap-8 mb-6 flex-wrap">
              <a href="mailto:talentohumanokingpapa@gmail.com" className="flex items-center gap-2 hover:text-yellow-400 transition-colors">
                <Mail className="h-5 w-5" /> <span>talentohumanokingpapa@gmail.com</span>
              </a>
              <a href="tel:+573168825477" className="flex items-center gap-2 hover:text-yellow-400 transition-colors">
                <Phone className="h-5 w-5" /> <span>+57 316 882 5477</span>
              </a>
              <a href="https://kingpapa.online" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-yellow-400 transition-colors">
                <Globe className="h-5 w-5" /> <span>kingpapa.online</span>
              </a>
            </div>
            <p className="mb-8 text-lg italic">“Somos reyes del sabor, pero también del servicio. Ven y haz historia con nosotros.”</p>
            <div className="flex justify-center">
              <Link to="/" data-testid="cta-dashboard-footer" aria-label="Ingresar al Dashboard" className="text-stone-600 hover:text-white hover:bg-stone-800 transition-colors text-xs opacity-70 hover:opacity-100 px-3 py-2 rounded-md">
                👑 Ingresar al Dashboard
              </Link>
            </div>
          </div>
        </footer>
      </div>
    </HelmetProvider>;
};
export default TalentLandingPage;