import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet-async';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { useCandidates } from '@/contexts/CandidateContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Eye, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const KANBAN_COLUMNS = {
  'pendiente': { title: 'Pendiente', color: 'bg-stone-500' },
  'procesando': { title: 'En Proceso', color: 'bg-sky-500' },
  'preseleccionado': { title: 'Preseleccionado', color: 'bg-blue-500' },
  'entrevistado': { title: 'Entrevistado', color: 'bg-purple-500' },
  'ofrecido': { title: 'Ofrecido', color: 'bg-yellow-500' },
  'contratado': { title: 'Contratado', color: 'bg-green-500' },
  'descartado': { title: 'Descartado', color: 'bg-red-500' },
  'error': { title: 'Error', color: 'bg-orange-500' },
};

const CandidateCard = ({ candidate, index }) => {
    const navigate = useNavigate();
    return (
        <Draggable draggableId={candidate.id} index={index}>
            {(provided, snapshot) => (
                <div
                    ref={provided.innerRef}
                    {...provided.draggableProps}
                    {...provided.dragHandleProps}
                    className={`p-3 mb-3 rounded-lg shadow-md bg-stone-800 border border-stone-700 ${snapshot.isDragging ? 'ring-2 ring-primary' : ''}`}
                >
                    <p className="font-bold text-stone-100">{candidate.nombre}</p>
                    <p className="text-xs text-stone-400">{candidate.ciudad}</p>
                    <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center gap-1 text-sm font-bold text-amber-400">
                            <Star className="h-4 w-4" />
                            {candidate.puntaje_total || 'N/A'}
                        </div>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => navigate(`/candidates/${candidate.id}`)}>
                            <Eye className="h-4 w-4" />
                        </Button>
                    </div>
                </div>
            )}
        </Draggable>
    );
};

const KanbanColumn = ({ columnId, column, candidates }) => {
    return (
        <div className="flex flex-col w-full md:w-64 lg:w-80 bg-stone-900 rounded-lg shadow-lg">
            <div className={`p-3 rounded-t-lg flex justify-between items-center ${column.color}`}>
                <h2 className="font-bold text-white">{column.title}</h2>
                <span className="text-sm font-semibold text-white bg-black/20 rounded-full px-2 py-0.5">{candidates.length}</span>
            </div>
            <Droppable droppableId={columnId}>
                {(provided, snapshot) => (
                    <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`p-2 flex-grow min-h-[100px] transition-colors ${snapshot.isDraggingOver ? 'bg-stone-800/50' : ''}`}
                    >
                        {candidates.map((candidate, index) => (
                            <CandidateCard key={candidate.id} candidate={candidate} index={index} />
                        ))}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </div>
    );
};

const KanbanPage = () => {
    const { candidates, loading } = useCandidates();
    const { toast } = useToast();
    const [boardData, setBoardData] = useState({});
    const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
    const [updateData, setUpdateData] = useState(null);
    const [comment, setComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        const newBoardData = Object.keys(KANBAN_COLUMNS).reduce((acc, key) => {
            acc[key] = [];
            return acc;
        }, {});

        candidates.forEach(candidate => {
            const status = candidate.evaluacion_estado || 'pendiente';
            if (newBoardData[status]) {
                newBoardData[status].push(candidate);
            }
        });
        setBoardData(newBoardData);
    }, [candidates]);

    const onDragEnd = (result) => {
        const { source, destination, draggableId } = result;
        if (!destination || (source.droppableId === destination.droppableId)) {
            return;
        }
        
        const candidate = candidates.find(c => c.id === draggableId);
        setUpdateData({
            candidate,
            newStatus: destination.droppableId,
            oldStatus: source.droppableId
        });
        setIsUpdateModalOpen(true);
    };

    const handleConfirmUpdate = async () => {
        if (!comment.trim()) {
            toast({ variant: 'destructive', title: 'Comentario requerido', description: 'Debes añadir un comentario para cambiar el estado.' });
            return;
        }
        setIsSubmitting(true);
        try {
            const { error } = await supabase.rpc('update_candidate_status_with_comment', {
                p_candidate_id: updateData.candidate.id,
                p_new_status: updateData.newStatus,
                p_comment: comment
            });
            if (error) throw error;
            toast({ variant: 'success', title: 'Estado actualizado', description: `El estado de ${updateData.candidate.nombre} ha sido actualizado.` });
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error al actualizar', description: error.message });
        } finally {
            setIsSubmitting(false);
            setIsUpdateModalOpen(false);
            setComment('');
            setUpdateData(null);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
    }

    return (
        <PageTransition>
            <Helmet>
                <title>Pipeline Kanban | Reino del Talento</title>
                <meta name="description" content="Vista Kanban del pipeline de candidatos." />
            </Helmet>
            <DragDropContext onDragEnd={onDragEnd}>
                <div className="flex flex-col md:flex-row gap-4 overflow-x-auto pb-4">
                    {Object.entries(KANBAN_COLUMNS).map(([columnId, column]) => (
                        <KanbanColumn
                            key={columnId}
                            columnId={columnId}
                            column={column}
                            candidates={boardData[columnId] || []}
                        />
                    ))}
                </div>
            </DragDropContext>

            {updateData && (
                <Dialog open={isUpdateModalOpen} onOpenChange={setIsUpdateModalOpen}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Cambiar estado de {updateData.candidate.nombre}</DialogTitle>
                            <DialogDescription>
                                Estás moviendo al candidato de "{KANBAN_COLUMNS[updateData.oldStatus].title}" a "{KANBAN_COLUMNS[updateData.newStatus].title}".
                                Por favor, añade un comentario para registrar esta acción.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="py-4">
                            <Textarea
                                placeholder="Ej: El candidato pasó la entrevista técnica..."
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                            />
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setIsUpdateModalOpen(false)}>Cancelar</Button>
                            <Button onClick={handleConfirmUpdate} disabled={isSubmitting}>
                                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Confirmar
                            </Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            )}
        </PageTransition>
    );
};

export default KanbanPage;