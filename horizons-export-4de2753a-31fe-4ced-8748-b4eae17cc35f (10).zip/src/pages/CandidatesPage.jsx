import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useCandidates } from '@/contexts/CandidateContext';
import { useToast } from "@/components/ui/use-toast";
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Eye, RefreshCw, Trash2, Loader2, AlertTriangle, Briefcase, Search, Sparkles, Save } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { supabase } from '@/lib/customSupabaseClient';

const RecommendationBadge = ({ recommendation }) => {
  const baseClasses = 'px-2 py-1 text-xs font-semibold rounded-full inline-block';
  switch (recommendation) {
    case 'CONTRATAR': return <span className={`${baseClasses} bg-green-500/20 text-green-400`}>CONTRATAR</span>;
    case 'ENTREVISTAR': return <span className={`${baseClasses} bg-sky-500/20 text-sky-400`}>ENTREVISTAR</span>;
    case 'REVISAR': return <span className={`${baseClasses} bg-yellow-500/20 text-yellow-400`}>REVISAR</span>;
    case 'DESCARTAR': return <span className={`${baseClasses} bg-red-500/20 text-red-400`}>DESCARTAR</span>;
    default: return null;
  }
};

const StatusBadge = ({ status }) => {
    const baseClasses = 'px-2 py-1 text-xs font-semibold rounded-full inline-block';
    switch (status) {
        case 'listo': return <span className={`${baseClasses} bg-green-500/20 text-green-400`}>Listo</span>;
        case 'procesando': return <span className={`${baseClasses} bg-sky-500/20 text-sky-400`}><Loader2 className="inline mr-1 h-3 w-3 animate-spin" />Procesando</span>;
        case 'error': return <span className={`${baseClasses} bg-red-500/20 text-red-400`}><AlertTriangle className="inline mr-1 h-3 w-3" />Error</span>;
        case 'contratado': return <span className={`${baseClasses} bg-indigo-500/20 text-indigo-400`}>Contratado</span>;
        case 'pendiente':
        default: return <span className={`${baseClasses} bg-stone-500/20 text-stone-400`}>Pendiente</span>;
    }
};

const RecruiterStatusEditor = ({ candidateId, currentStatus }) => {
    const { toast } = useToast();
    const [status, setStatus] = useState(currentStatus);
    const [isSaving, setIsSaving] = useState(false);
    const recruiterStatusOptions = ["Pendiente", "Citado a entrevista", "Entrevistado", "Contratado", "Descartado"];

    const handleStatusChange = async (newStatus) => {
        setIsSaving(true);
        setStatus(newStatus);
        
        let updatePayload = { recruiter_status: newStatus };
        if (newStatus === 'Contratado') {
            updatePayload.recomendacion = 'CONTRATAR';
        } else if (newStatus === 'Descartado') {
            updatePayload.recomendacion = 'DESCARTAR';
        }

        const { error } = await supabase
            .from('candidates')
            .update(updatePayload)
            .eq('id', candidateId);

        if (error) {
            toast({ variant: "destructive", title: "Error al actualizar", description: error.message });
            setStatus(currentStatus); // Revert on error
        } else {
            toast({
                title: "💾 Guardado",
                description: "El estado del reclutador ha sido actualizado.",
                duration: 2000,
            });
        }
        setIsSaving(false);
    };

    return (
        <div className="flex items-center gap-2">
            <Select value={status} onValueChange={handleStatusChange} disabled={isSaving}>
                <SelectTrigger className="w-[180px] bg-stone-800 border-stone-700 h-9">
                    <SelectValue placeholder="Estado" />
                </SelectTrigger>
                <SelectContent className="bg-stone-800 border-stone-700 text-stone-100">
                    {recruiterStatusOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                </SelectContent>
            </Select>
            {isSaving && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
        </div>
    );
};


const CandidatesPage = () => {
  const { candidates, locations, loading, assignCandidateToLocation } = useCandidates();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [conceptSearchTerm, setConceptSearchTerm] = useState('');
  const [isConceptSearching, setIsConceptSearching] = useState(false);
  const [conceptResults, setConceptResults] = useState(null);
  const [filters, setFilters] = useState({ city: 'all', location: 'all', status: 'all', recommendation: 'all', skill: 'all' });
  const [prioritizeByVacancy, setPrioritizeByVacancy] = useState(false);

  const [evaluatingId, setEvaluatingId] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [hiringCandidate, setHiringCandidate] = useState(null);
  const [selectedHireLocation, setSelectedHireLocation] = useState('');
  const [isHiring, setIsHiring] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const locationFilter = params.get('location');
    if (locationFilter) {
      const decodedLocation = decodeURIComponent(locationFilter);
      const foundLocation = locations.find(l => l.name === decodedLocation);
      if (foundLocation) setFilters(prev => ({ ...prev, location: foundLocation.name }));
    }
  }, [location.search, locations]);

  const handleFilterChange = (filterName) => (value) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
  };

  const handleConceptSearch = useCallback(async () => {
    if (!conceptSearchTerm.trim()) {
        setConceptResults(null);
        return;
    }
    setIsConceptSearching(true);
    try {
        const { data, error } = await supabase.rpc('search_candidates_by_concept', {
            search_term: conceptSearchTerm
        });

        if (error) {
          throw new Error(error.message);
        }
        
        setConceptResults(data);

    } catch (error) {
        toast({ variant: "destructive", title: "Error en búsqueda por concepto", description: error.message });
        setConceptResults([]);
    } finally {
        setIsConceptSearching(false);
    }
  }, [conceptSearchTerm, toast]);

  const recommendationOrder = { 'CONTRATAR': 1, 'ENTREVISTAR': 2, 'REVISAR': 3, 'DESCARTAR': 4, 'PENDIENTE': 5 };

  const filteredAndSortedCandidates = useMemo(() => {
    if (conceptResults) {
        return conceptResults;
    }

    let filtered = candidates.filter(c => {
      const lowerCaseSearchTerm = searchTerm.toLowerCase();
      const nameMatch = c.nombre?.toLowerCase().includes(lowerCaseSearchTerm);
      const suggestionMatch = Array.isArray(c.sugerencias_puesto) && c.sugerencias_puesto.some(sug => sug.title?.toLowerCase().includes(lowerCaseSearchTerm));
      const searchMatch = nameMatch || suggestionMatch;

      const cityMatch = filters.city === 'all' || c.ciudad === filters.city;
      const locationMatch = filters.location === 'all' || c.ubicacion_interes === filters.location;
      const statusMatch = filters.status === 'all' || c.evaluacion_estado === filters.status;
      const recommendationMatch = filters.recommendation === 'all' || (c.recomendacion || 'PENDIENTE') === filters.recommendation;
      
      return searchMatch && cityMatch && locationMatch && statusMatch && recommendationMatch;
    });

    if (prioritizeByVacancy) {
        filtered.sort((a, b) => {
            const aHasVacancy = (a.locations?.vacancies || 0) > 0;
            const bHasVacancy = (b.locations?.vacancies || 0) > 0;
            if (aHasVacancy !== bHasVacancy) return bHasVacancy - aHasVacancy;
            const recA = recommendationOrder[a.recomendacion || 'PENDIENTE'];
            const recB = recommendationOrder[b.recomendacion || 'PENDIENTE'];
            if (recA !== recB) return recA - recB;
            return (b.puntaje_total || 0) - (a.puntaje_total || 0);
        });
    }

    return filtered;
  }, [candidates, searchTerm, filters, prioritizeByVacancy, conceptResults]);

  const uniqueLocations = [...new Set(locations.map(c => c.name).filter(Boolean))];
  const uniqueStatuses = [...new Set(candidates.map(c => c.evaluacion_estado).filter(Boolean))];
  const uniqueRecommendations = ['CONTRATAR', 'ENTREVISTAR', 'REVISAR', 'DESCARTAR', 'PENDIENTE'];
  const hireableLocations = locations.filter(l => l.vacancies > 0);

  const handleReanalyze = async (candidateId) => {
    setEvaluatingId(candidateId);
    toast({ title: "Iniciando re-análisis..." });
    try {
      const { error } = await supabase.functions.invoke('reevaluate-candidate', { body: { candidate_id: candidateId } });
      if (error) throw error;
      toast({ variant: "success", title: "Re-análisis completado" });
    } catch (error) {
      toast({ variant: "destructive", title: "Error en el re-análisis", description: error.message });
    } finally {
      setEvaluatingId(null);
    }
  };

  const handleDelete = async (candidateId) => {
    setDeletingId(candidateId);
    try {
      const { error } = await supabase.functions.invoke('delete-candidate', { body: { candidateId } });
      if (error) throw error;
      toast({ variant: "success", title: "Candidato eliminado" });
    } catch (error) {
      toast({ variant: "destructive", title: "Error al eliminar", description: error.message });
    } finally {
      setDeletingId(null);
    }
  };

  const handleHire = async () => {
    if (!selectedHireLocation) {
        toast({ variant: "destructive", title: "Seleccione una sede para contratar." });
        return;
    }
    setIsHiring(true);
    try {
        await assignCandidateToLocation(hiringCandidate.id, selectedHireLocation);
        toast({ variant: "success", title: "¡Candidato Contratado!" });
        setHiringCandidate(null);
        setSelectedHireLocation('');
    } catch(error) {
        toast({ variant: "destructive", title: "Error al contratar", description: error.message });
    } finally {
        setIsHiring(false);
    }
  };

  return (
    <PageTransition>
        <Helmet><title>Candidatos | Reino del Talento</title></Helmet>
        <Card className="bg-stone-900 border-stone-800">
            <CardHeader><CardTitle className="text-stone-100">Lista de Candidatos</CardTitle></CardHeader>
            <CardContent>
                <div className="space-y-4 mb-6">
                    <div className="flex gap-2">
                        <Input placeholder="Buscar por concepto (ej: líder con experiencia en cocina)..." value={conceptSearchTerm} onChange={(e) => setConceptSearchTerm(e.target.value)} className="flex-grow bg-stone-800 border-stone-700 placeholder:text-stone-500" />
                        <Button onClick={handleConceptSearch} disabled={isConceptSearching}>{isConceptSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}</Button>
                    </div>
                    <div className="flex flex-wrap gap-4">
                        <Input placeholder="Buscar por nombre o puesto sugerido..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="max-w-xs bg-stone-800 border-stone-700 placeholder:text-stone-500" />
                        <Select value={filters.location} onValueChange={handleFilterChange('location')}><SelectTrigger className="w-full sm:w-[180px] bg-stone-800 border-stone-700"><SelectValue placeholder="Filtrar por sede" /></SelectTrigger><SelectContent className="bg-stone-800 border-stone-700 text-stone-100"><SelectItem value="all">Todas las sedes</SelectItem>{uniqueLocations.map(loc => <SelectItem key={loc} value={loc}>{loc}</SelectItem>)}</SelectContent></Select>
                        <Select value={filters.status} onValueChange={handleFilterChange('status')}><SelectTrigger className="w-full sm:w-[180px] bg-stone-800 border-stone-700"><SelectValue placeholder="Estado IA" /></SelectTrigger><SelectContent className="bg-stone-800 border-stone-700 text-stone-100"><SelectItem value="all">Todos</SelectItem>{uniqueStatuses.map(s => s && <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
                        <Select value={filters.recommendation} onValueChange={handleFilterChange('recommendation')}><SelectTrigger className="w-full sm:w-[180px] bg-stone-800 border-stone-700"><SelectValue placeholder="Recomendación IA" /></SelectTrigger><SelectContent className="bg-stone-800 border-stone-700 text-stone-100"><SelectItem value="all">Todas</SelectItem>{uniqueRecommendations.map(rec => rec && <SelectItem key={rec} value={rec}>{rec}</SelectItem>)}</SelectContent></Select>
                        <div className="flex items-center space-x-2"><Switch id="prioritize" checked={prioritizeByVacancy} onCheckedChange={setPrioritizeByVacancy} /><Label htmlFor="prioritize">Priorizar por vacantes</Label></div>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader><TableRow className="border-stone-700 hover:bg-stone-800/50">
                            <TableHead className="text-stone-300">Nombre</TableHead>
                            <TableHead className="text-stone-300">Sede Preferida</TableHead>
                            <TableHead className="text-stone-300 text-center">Recomendación IA</TableHead>
                            <TableHead className="text-stone-300">Estado Reclutador</TableHead>
                            <TableHead className="text-stone-300 text-right">Acciones</TableHead>
                        </TableRow></TableHeader>
                        <TableBody>
                            {loading ? (<TableRow><TableCell colSpan={5} className="text-center py-10">Cargando candidatos...</TableCell></TableRow>
                            ) : filteredAndSortedCandidates.map(candidate => (
                                <TableRow key={candidate.id} className="border-stone-800 hover:bg-stone-800/50">
                                    <TableCell className="font-medium text-stone-100">{candidate.nombre}</TableCell>
                                    <TableCell className="text-stone-400">{candidate.ubicacion_interes || candidate.locations?.name}{ (candidate.locations?.vacancies || 0) > 0 && <span className="ml-2 px-2 py-0.5 text-xs font-semibold rounded-full bg-sky-500/20 text-sky-400">¡Hay vacantes!</span>}</TableCell>
                                    <TableCell className="text-center"><RecommendationBadge recommendation={candidate.recomendacion} /></TableCell>
                                    <TableCell>
                                        <RecruiterStatusEditor candidateId={candidate.id} currentStatus={candidate.recruiter_status} />
                                    </TableCell>
                                    <TableCell className="text-right"><div className="flex gap-1 justify-end">
                                        {candidate.recomendacion === 'CONTRATAR' && <Button variant="outline" size="icon" onClick={() => setHiringCandidate(candidate)} disabled={isHiring} title="Contratar"><Briefcase className="h-4 w-4 text-green-500" /></Button>}
                                        <Button variant="ghost" size="icon" onClick={() => navigate(`/candidates/${candidate.id}`)} title="Ver detalle"><Eye className="h-4 w-4 text-stone-400" /></Button>
                                        <Button variant="ghost" size="icon" onClick={() => handleReanalyze(candidate.id)} disabled={evaluatingId === candidate.id} title="Reanalizar IA">{evaluatingId === candidate.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4 text-stone-400" />}</Button>
                                        <Dialog><DialogTrigger asChild><Button variant="ghost" size="icon" disabled={deletingId === candidate.id} title="Eliminar"><Trash2 className="h-4 w-4 text-red-500" /></Button></DialogTrigger>
                                        <DialogContent><DialogHeader><DialogTitle>¿Eliminar a este candidato?</DialogTitle><DialogDescription>Esta acción no se puede deshacer.</DialogDescription></DialogHeader>
                                        <DialogFooter><DialogClose asChild><Button variant="outline">Cancelar</Button></DialogClose><DialogClose asChild><Button variant="destructive" onClick={() => handleDelete(candidate.id)} disabled={deletingId === candidate.id}>{deletingId === candidate.id && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Sí, eliminar</Button></DialogClose></DialogFooter></DialogContent></Dialog>
                                    </div></TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                    {!loading && filteredAndSortedCandidates.length === 0 && <p className="text-center py-8 text-stone-500">No se encontraron candidatos.</p>}
                </div>
            </CardContent>
        </Card>
        {hiringCandidate && (
             <Dialog open={!!hiringCandidate} onOpenChange={(open) => !open && setHiringCandidate(null)}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Contratar a {hiringCandidate.nombre}</DialogTitle><DialogDescription>Selecciona la sede a la que será asignado.</DialogDescription></DialogHeader>
                    <div className="py-4">
                        <Label htmlFor="hire-location">Asignar a sede</Label>
                        <Select onValueChange={setSelectedHireLocation} value={selectedHireLocation}>
                            <SelectTrigger id="hire-location"><SelectValue placeholder="Selecciona una sede con vacantes" /></SelectTrigger>
                            <SelectContent>{hireableLocations.map(loc => (<SelectItem key={loc.id} value={loc.id}>{loc.name} ({loc.vacancies} vacantes)</SelectItem>))}</SelectContent>
                        </Select>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setHiringCandidate(null)}>Cancelar</Button>
                        <Button onClick={handleHire} disabled={isHiring || !selectedHireLocation}>{isHiring ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Briefcase className="mr-2 h-4 w-4" />}Confirmar</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        )}
    </PageTransition>
  );
};

export default CandidatesPage;