import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { addDays, format } from 'date-fns';
import { supabase } from '@/lib/customSupabaseClient';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';

const StatCard = ({ title, value, description }) => (
    <Card className="bg-stone-900 border-stone-800">
        <CardHeader>
            <CardTitle className="text-sm font-medium text-stone-400">{title}</CardTitle>
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold text-amber-400">{value}</div>
            <p className="text-xs text-stone-500">{description}</p>
        </CardContent>
    </Card>
);

const COLORS = ['#f59e0b', '#eab308', '#84cc16', '#22c55e', '#06b6d4', '#8b5cf6'];

const AnalyticsPage = () => {
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState({ funnel: [], sla: {}, weekly: [] });
    const [date, setDate] = useState({ from: addDays(new Date(), -30), to: new Date() });

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const [funnelRes, slaRes, weeklyRes] = await Promise.all([
                    supabase.from('vw_recruiting_funnel').select('*'),
                    supabase.from('vw_sla_metrics').select('*').single(),
                    supabase.from('vw_recruiting_funnel').select('week, total_applications')
                ]);

                if (funnelRes.error) throw funnelRes.error;
                if (slaRes.error) throw slaRes.error;
                if (weeklyRes.error) throw weeklyRes.error;

                const funnelData = funnelRes.data.reduce((acc, week) => {
                    Object.keys(week).forEach(key => {
                        if (key !== 'week') {
                            acc[key] = (acc[key] || 0) + week[key];
                        }
                    });
                    return acc;
                }, {});
                
                const formattedFunnel = [
                    { name: 'Postulados', value: funnelData.total_applications || 0 },
                    { name: 'Preseleccionados', value: funnelData.preselected || 0 },
                    { name: 'Entrevistados', value: funnelData.interviewed || 0 },
                    { name: 'Ofertados', value: funnelData.offered || 0 },
                    { name: 'Contratados', value: funnelData.hired || 0 },
                ];

                setData({
                    funnel: formattedFunnel,
                    sla: slaRes.data,
                    weekly: weeklyRes.data.map(d => ({...d, week: format(new Date(d.week), 'MMM dd')}))
                });

            } catch (error) {
                console.error("Error fetching analytics data:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, [date]);

    return (
        <PageTransition>
            <Helmet>
                <title>Analytics | Reino del Talento</title>
                <meta name="description" content="Analytics y métricas del proceso de reclutamiento." />
            </Helmet>
            <div className="space-y-6">
                <div className="flex justify-between items-center">
                    <h1 className="text-3xl font-bold">Analytics de Reclutamiento</h1>
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant={"outline"}>
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {date?.from ? (
                                    date.to ? (
                                        <>{format(date.from, "LLL dd, y")} - {format(date.to, "LLL dd, y")}</>
                                    ) : (
                                        format(date.from, "LLL dd, y")
                                    )
                                ) : (
                                    <span>Pick a date</span>
                                )}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="end">
                            <Calendar
                                initialFocus
                                mode="range"
                                defaultMonth={date?.from}
                                selected={date}
                                onSelect={setDate}
                                numberOfMonths={2}
                            />
                        </PopoverContent>
                    </Popover>
                </div>

                {loading ? (
                    <div className="flex justify-center items-center h-96"><Loader2 className="h-8 w-8 animate-spin" /></div>
                ) : (
                    <>
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                            <StatCard title="Total Postulaciones" value={data.funnel[0]?.value || 0} description="En el período seleccionado" />
                            <StatCard title="Tasa de Contratación" value={`${data.funnel[0]?.value > 0 ? ((data.funnel[4]?.value / data.funnel[0]?.value) * 100).toFixed(1) : 0}%`} description="Desde postulación a contratación" />
                            <StatCard title="Time to Hire (días)" value={data.sla.avg_time_to_hire_days?.toFixed(1) || 'N/A'} description="Promedio para contratar" />
                            <StatCard title="Time to First Contact (hrs)" value={data.sla.avg_time_to_first_contact_hours?.toFixed(1) || 'N/A'} description="Promedio para primer contacto" />
                        </div>

                        <div className="grid gap-6 lg:grid-cols-2">
                            <Card className="bg-stone-900 border-stone-800">
                                <CardHeader><CardTitle>Embudo de Conversión</CardTitle></CardHeader>
                                <CardContent className="h-[350px]">
                                    <ResponsiveContainer>
                                        <BarChart data={data.funnel} layout="vertical" margin={{ left: 100 }}>
                                            <XAxis type="number" hide />
                                            <YAxis type="category" dataKey="name" width={100} tick={{ fill: '#a8a29e' }} tickLine={false} axisLine={false} />
                                            <Tooltip contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #44403c' }} />
                                            <Bar dataKey="value" fill="#fbbf24" background={{ fill: '#292524' }} radius={[4, 4, 4, 4]} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>
                            <Card className="bg-stone-900 border-stone-800">
                                <CardHeader><CardTitle>Postulaciones por Semana</CardTitle></CardHeader>
                                <CardContent className="h-[350px]">
                                    <ResponsiveContainer>
                                        <LineChart data={data.weekly}>
                                            <XAxis dataKey="week" stroke="#a8a29e" />
                                            <YAxis stroke="#a8a29e" />
                                            <Tooltip contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #44403c' }} />
                                            <Legend />
                                            <Line type="monotone" dataKey="total_applications" name="Postulaciones" stroke="#fbbf24" strokeWidth={2} />
                                        </LineChart>
                                    </ResponsiveContainer>
                                </CardContent>
                            </Card>
                        </div>
                    </>
                )}
            </div>
        </PageTransition>
    );
};

export default AnalyticsPage;