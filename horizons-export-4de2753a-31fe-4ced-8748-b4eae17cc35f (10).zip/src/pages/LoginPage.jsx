import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Flame, LogIn } from 'lucide-react';

const LoginPage = () => {
    const navigate = useNavigate();
    const { signIn, session, signOut } = useAuth();
    const { toast } = useToast();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (session) {
            signOut();
        }
    }, []);

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true);
        const { error } = await signIn(email, password);
        if (error) {
            // Toast is already handled in signIn
        } else {
            toast({
                variant: 'success',
                title: '¡Bienvenido!',
                description: 'Has iniciado sesión correctamente.',
            });
            navigate('/');
        }
        setLoading(false);
    };

    return (
        <PageTransition>
            <Helmet>
                <title>Login | Reino del Talento</title>
                <meta name="description" content="Accede al panel de administración del sistema de reclutamiento." />
            </Helmet>
            <div className="min-h-screen bg-background flex items-center justify-center p-4">
                <div className="w-full max-w-sm">
                    <div className="flex justify-center items-center gap-4 mb-6">
                        <Flame className="h-12 w-12 text-primary" />
                        <h1 className="text-3xl font-bold text-center text-foreground">Reino del Talento</h1>
                    </div>
                    <Card className="bg-card border-border">
                        <CardHeader>
                            <CardTitle className="text-2xl text-foreground">Acceso RRHH</CardTitle>
                            <CardDescription className="text-muted-foreground">Ingresa tus credenciales para continuar</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleLogin} className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="email">Email</Label>
                                    <Input 
                                        id="email" 
                                        type="email" 
                                        placeholder="tu@email.com" 
                                        required 
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="password">Contraseña</Label>
                                    <Input 
                                        id="password" 
                                        type="password" 
                                        required 
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                </div>
                                <Button type="submit" className="w-full" disabled={loading}>
                                    {loading ? 'Ingresando...' : <> <LogIn className="mr-2 h-4 w-4" /> Ingresar </>}
                                </Button>
                            </form>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </PageTransition>
    );
};

export default LoginPage;