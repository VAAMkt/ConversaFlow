import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { useCandidates } from '@/contexts/CandidateContext';
import { useToast } from '@/components/ui/use-toast';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, User, Mail, Phone, MapPin, FileText, Calendar, BrainCircuit, CheckCircle, XCircle, Loader2, AlertTriangle, RefreshCw, Briefcase, Clock, CircleDot, AlertOctagon, ShieldAlert, Star, ChevronDown, DollarSign, TrendingUp, Edit, Trash2, Crown } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import CvAnalysisDashboard from '@/components/CvAnalysisDashboard';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { useSettings } from '@/contexts/SettingsContext';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

const RecommendationBadge = ({ recommendation, className = '' }) => {
  const baseClasses = 'px-4 py-2 text-sm font-bold rounded-lg inline-flex items-center gap-2';
  switch (recommendation) {
    case 'CONTRATAR':
      return <div className={`${baseClasses} bg-green-500/20 text-green-400 ${className}`}><CheckCircle className="h-5 w-5" />CONTRATAR</div>;
    case 'ENTREVISTAR':
      return <div className={`${baseClasses} bg-sky-500/20 text-sky-400 ${className}`}>ENTREVISTAR</div>;
    case 'REVISAR':
      return <div className={`${baseClasses} bg-yellow-500/20 text-yellow-400 ${className}`}>REVISAR</div>;
    case 'DESCARTAR':
      return <div className={`${baseClasses} bg-red-500/20 text-red-400 ${className}`}><XCircle className="h-5 w-5" />DESCARTAR</div>;
    default:
      return <div className={`${baseClasses} bg-stone-500/20 text-stone-400 ${className}`}>PENDIENTE</div>;
  }
};

const StatusBadge = ({ status }) => {
    const baseClasses = 'px-3 py-1 text-xs font-bold rounded-full inline-block';
    switch (status) {
        case 'listo': return <span className={`${baseClasses} bg-green-500/20 text-green-400`}>Listo</span>;
        case 'procesando': return <span className={`${baseClasses} bg-sky-500/20 text-sky-400`}><Loader2 className="inline mr-1 h-3 w-3 animate-spin" />Procesando</span>;
        case 'contratado': return <span className={`${baseClasses} bg-violet-500/20 text-violet-400`}><CheckCircle className="inline mr-1 h-3 w-3"/>Contratado</span>;
        case 'error': return <span className={`${baseClasses} bg-red-500/20 text-red-400`}><AlertTriangle className="inline mr-1 h-3 w-3" />Error</span>;
        case 'pendiente': default: return <span className={`${baseClasses} bg-stone-500/20 text-stone-400`}>Pendiente</span>;
    }
};

const ScoreBar = ({ label, score }) => {
    const getScoreInfo = (s) => {
        if (s >= 19) return { label: 'Alto', color: 'bg-green-500', textColor: 'text-green-400' };
        if (s >= 11) return { label: 'Medio', color: 'bg-yellow-500', textColor: 'text-yellow-400' };
        return { label: 'Bajo', color: 'bg-red-500', textColor: 'text-red-400' };
    };
    const scoreInfo = getScoreInfo(score);

    return (
        <div className="w-full">
            <div className="flex justify-between items-center mb-1">
                <p className="text-sm font-medium text-stone-300">{label}</p>
                <div className="flex items-center gap-2">
                    <Badge variant="outline" className={`${scoreInfo.textColor} border-current`}>{scoreInfo.label}</Badge>
                    <p className={`text-sm font-bold ${scoreInfo.textColor}`}>{score}/25</p>
                </div>
            </div>
            <div className="w-full bg-stone-700 rounded-full h-2"><div className={`${scoreInfo.color} h-2 rounded-full`} style={{ width: `${(score/25)*100}%` }}></div></div>
        </div>
    );
};

const QuickInfoItem = ({ icon, label, value, isBadge = false }) => (
    <div className="flex items-start text-sm">
        <div className="flex-shrink-0 w-6 pt-0.5">{icon}</div>
        <div>
            <p className="font-semibold text-stone-300">{label}</p>
            {isBadge ? <Badge variant="secondary" className="mt-1 bg-amber-400/10 text-amber-300">{value}</Badge> : <p className="text-stone-400">{value}</p>}
        </div>
    </div>
);

const SuggestedPositionCard = ({ title, score, reasons }) => {
    const getScoreColor = (s) => {
        if (s >= 70) return 'text-green-400';
        if (s >= 50) return 'text-yellow-400';
        return 'text-red-400';
    };
    return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger asChild>
                    <div className="bg-stone-800/50 p-3 rounded-lg border border-stone-700 hover:border-amber-400/50 transition-colors cursor-pointer">
                        <div className="flex justify-between items-center">
                            <p className="font-bold text-stone-200 text-sm">{title}</p>
                            <span className={`font-bold text-sm ${getScoreColor(score)}`}>{score}%</span>
                        </div>
                    </div>
                </TooltipTrigger>
                <TooltipContent>
                    <p className="max-w-xs">{reasons}</p>
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
    );
};

const RecruiterStatusIcon = ({ status }) => {
    const statusMap = {
        "Pendiente": { icon: <CircleDot className="h-5 w-5 text-yellow-400" />, color: "text-yellow-400" },
        "Citado a entrevista": { icon: <User className="h-5 w-5 text-stone-400" />, color: "text-stone-400" },
        "Entrevistado": { icon: <CheckCircle className="h-5 w-5 text-green-400" />, color: "text-green-400" },
        "Contratado": { icon: <Crown className="h-5 w-5 text-amber-400" />, color: "text-amber-400" },
        "Descartado": { icon: <Trash2 className="h-5 w-5 text-red-500" />, color: "text-red-500" },
    };
    const { icon, color } = statusMap[status] || statusMap["Pendiente"];
    return <div className="flex items-center gap-2"><span className={color}>{icon}</span><span className={color}>{status}</span></div>;
};

const CandidateDetailPage = () => {
  const { id } = useParams();
  const { getCandidateById, getSignedUrl } = useCandidates();
  const { toast } = useToast();
  const { settings } = useSettings();
  const [candidate, setCandidate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [cvUrl, setCvUrl] = useState('#');
  const [processingState, setProcessingState] = useState('idle');
  const [percentile, setPercentile] = useState(null);
  const [recruiterNotes, setRecruiterNotes] = useState('');
  const [isSavingNotes, setIsSavingNotes] = useState(false);

  const recruiterStatusOptions = ["Pendiente", "Citado a entrevista", "Entrevistado", "Contratado", "Descartado"];

  const fetchAllData = useCallback(async () => {
    setLoading(true);
    try {
        const candidateData = await getCandidateById(id);
        setCandidate(candidateData);
        setRecruiterNotes(candidateData?.recruiter_notes || '');

        if (candidateData && candidateData.cv_path) {
            const url = await getSignedUrl('recruitment-cv', candidateData.cv_path);
            setCvUrl(url || '#');
        }
        
        if (candidateData?.puntaje_total) {
            const { data: avgData } = await supabase.rpc('get_average_candidate_score');
            const avgScore = avgData || 65;
            const calculatedPercentile = Math.min(99, Math.round((candidateData.puntaje_total / (avgScore * 1.5)) * 100));
            setPercentile(calculatedPercentile);
        }

    } catch (error) {
        console.error("Error fetching candidate data:", error);
        toast({ variant: "destructive", title: "Error", description: "No se pudo cargar la información del candidato." });
    } finally {
        setLoading(false);
    }
  }, [id, getCandidateById, getSignedUrl, toast]);
  
  useEffect(() => {
    const channel = supabase.channel(`candidate-detail-${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'candidates', filter: `id=eq.${id}` }, () => fetchAllData())
      .subscribe();
      
    fetchAllData();

    return () => { supabase.removeChannel(channel); };
  }, [id, fetchAllData]);

  const handleRecruiterStatusChange = async (newStatus) => {
    let updatePayload = { recruiter_status: newStatus };
    if (newStatus === 'Contratado') {
        updatePayload.recomendacion = 'CONTRATAR';
    } else if (newStatus === 'Descartado') {
        updatePayload.recomendacion = 'DESCARTAR';
    }

    const { error } = await supabase.from('candidates').update(updatePayload).eq('id', id);
    if (error) {
        toast({ variant: "destructive", title: "Error al actualizar estado" });
    } else {
        toast({ title: "Estado actualizado", duration: 2000 });
    }
  };

  const handleNotesChange = (e) => {
    setRecruiterNotes(e.target.value);
  };

  const saveNotes = useCallback(async () => {
    setIsSavingNotes(true);
    const { error } = await supabase.from('candidates').update({ recruiter_notes: recruiterNotes }).eq('id', id);
    if (error) {
        toast({ variant: "destructive", title: "Error al guardar notas" });
    } else {
        toast({ title: "💾 Notas guardadas", duration: 2000 });
    }
    setIsSavingNotes(false);
  }, [recruiterNotes, id, toast]);

  useEffect(() => {
    const handler = setTimeout(() => {
        if (candidate && recruiterNotes !== (candidate.recruiter_notes || '')) {
            saveNotes();
        }
    }, 1500);
    return () => clearTimeout(handler);
  }, [recruiterNotes, candidate, saveNotes]);

  const handleCvExtraction = async () => {
    const webhookUrl = settings.N8N_CV_EXTRACTION_WEBHOOK_URL;
    if (!webhookUrl) {
        toast({ variant: 'destructive', title: 'Webhook no configurado' });
        return Promise.reject(new Error("Webhook no configurado"));
    }
    setProcessingState('extracting');
    toast({ title: 'Paso 1: Extrayendo texto del CV...' });
    try {
        const response = await fetch(webhookUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ candidate_id: candidate.id }) });
        if (!response.ok) throw new Error(`Error del webhook: ${response.status}`);
        return new Promise((resolve) => {
            const interval = setInterval(async () => {
                const { data: updatedCandidate } = await supabase.from('candidates').select('cv_text, last_extraction_at').eq('id', candidate.id).single();
                if (updatedCandidate.cv_text && new Date(updatedCandidate.last_extraction_at) > new Date(candidate.last_extraction_at || 0)) {
                    clearInterval(interval);
                    toast({ variant: 'success', title: '¡CV Extraído!' });
                    resolve();
                }
            }, 10000);
        });
    } catch (error) { return Promise.reject(error); }
  };

  const handleReanalyze = async () => {
    setProcessingState('analyzing');
    toast({ title: "Paso 2: Iniciando re-análisis IA..." });
    try {
        const { error } = await supabase.functions.invoke('reevaluate-candidate', { body: { candidateId: id } });
        if (error) throw error;
        toast({ variant: "success", title: "¡Re-análisis completado!" });
        return Promise.resolve();
    } catch (error) { return Promise.reject(error); }
  };

  const handleFullProcess = async () => {
    try {
        await handleCvExtraction();
        await handleReanalyze();
        setProcessingState('done');
        toast({ variant: "success", title: "Proceso finalizado" });
    } catch (error) {
        setProcessingState('error');
        toast({ variant: "destructive", title: "Error en el proceso", description: error.message });
    } finally {
        setTimeout(() => setProcessingState('idle'), 2000);
    }
  };

  if (loading) return <PageTransition><div className="flex justify-center items-center h-screen"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div></PageTransition>;
  if (!candidate) return <PageTransition><div className="text-center"><h1 className="text-2xl font-bold">Candidato no encontrado</h1></div></PageTransition>;

  const { nombre, email, celular, ciudad, barrio, ubicacion_interes, puntaje_total, recomendacion, evaluacion_estado, disponibilidad, evaluado_at, inconsistency_flag, sugerencias_puesto, expectativa_salarial, recruiter_status, updated_at } = candidate;
  
  const radarData = [
    { subject: 'Servicio', A: candidate.p_servicio || 0, fullMark: 25 },
    { subject: 'Palabra', A: candidate.tener_palabra || 0, fullMark: 25 },
    { subject: 'Impacto', A: candidate.impacto_positivo || 0, fullMark: 25 },
    { subject: 'Mejora', A: candidate.mejora_continua || 0, fullMark: 25 },
  ];

  const getButtonContent = () => {
    switch (processingState) {
        case 'extracting': return <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Extrayendo...</>;
        case 'analyzing': return <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analizando...</>;
        case 'done': return <><CheckCircle className="mr-2 h-4 w-4" /> Completado</>;
        case 'error': return <><AlertTriangle className="mr-2 h-4 w-4" /> Error</>;
        default: return <><RefreshCw className="mr-2 h-4 w-4" /> Actualizar y Analizar</>;
    }
  };
  
  const formatCurrency = (value) => {
    if (!value) return 'No especificada';
    return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(value);
  };

  return (
    <PageTransition>
      <Helmet><title>{`Detalle de ${nombre} | Reino del Talento`}</title></Helmet>
      <div className="max-w-7xl mx-auto space-y-6">
         <Card className="bg-stone-900 border-stone-800 overflow-hidden">
            <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                    <div className="flex-1">
                        <div className="flex items-center gap-4 mb-2">
                             <h1 className="text-3xl font-bold text-amber-400">{nombre}</h1>
                             <StatusBadge status={evaluacion_estado} />
                             {recomendacion && <RecommendationBadge recommendation={recomendacion} className="ml-4" />}
                        </div>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-stone-400 mb-4">
                           <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-amber-400"/>{email}</div>
                           <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-amber-400"/>{celular}</div>
                           <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-amber-400"/>{ciudad}, {barrio}</div>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex rounded-md shadow-sm">
                            <Button onClick={handleFullProcess} disabled={processingState !== 'idle'} className="rounded-r-none z-10">
                                {getButtonContent()}
                            </Button>
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="default" size="icon" className="rounded-l-none border-l border-amber-500" disabled={processingState !== 'idle'}><ChevronDown className="h-4 w-4" /></Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={handleCvExtraction} disabled={processingState !== 'idle'}><RefreshCw className="mr-2 h-4 w-4" /> Actualizar CV (n8n)</DropdownMenuItem>
                                    <DropdownMenuItem onClick={handleReanalyze} disabled={processingState !== 'idle'}><BrainCircuit className="mr-2 h-4 w-4" /> Reanalizar IA</DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                        <Button asChild variant="outline" disabled={cvUrl === '#'}><a href={cvUrl} target="_blank" rel="noopener noreferrer"><FileText className="mr-2 h-4 w-4" /> Ver CV</a></Button>
                    </div>
                </div>
            </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
               <CvAnalysisDashboard candidate={candidate} />
               <Card className="bg-stone-900 border-stone-800">
                    <CardHeader>
                        <CardTitle className="text-xl flex items-center gap-2 text-stone-100"><Star className="h-6 w-6 text-amber-400"/> Valores KINGPAPA</CardTitle>
                        {evaluacion_estado === 'listo' ? <CardDescription>Puntaje General: <span className="font-bold text-2xl text-amber-400">{puntaje_total}</span>/100</CardDescription> : <CardDescription>Evaluación {evaluacion_estado}...</CardDescription>}
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {evaluacion_estado === 'listo' ? (
                            <>
                                <div className="space-y-6">
                                    <ScoreBar label="Pasión por el Servicio" score={candidate.p_servicio || 0} />
                                    <ScoreBar label="Tener Palabra" score={candidate.tener_palabra || 0} />
                                    <ScoreBar label="Impacto Positivo" score={candidate.impacto_positivo || 0} />
                                    <ScoreBar label="Mejora Continua" score={candidate.mejora_continua || 0} />
                                </div>
                                <div className="h-64 md:h-auto flex flex-col justify-center">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                                            <PolarGrid stroke="#44403c" />
                                            <PolarAngleAxis dataKey="subject" tick={{ fill: '#d6d3d1', fontSize: 12 }} />
                                            <PolarRadiusAxis angle={30} domain={[0, 25]} tick={false} axisLine={false} />
                                            <Radar name={nombre} dataKey="A" stroke="#fbbf24" fill="#fbbf24" fillOpacity={0.6} />
                                        </RadarChart>
                                    </ResponsiveContainer>
                                </div>
                                {percentile !== null && (
                                    <div className="md:col-span-2 mt-4">
                                        <h4 className="text-sm font-semibold text-stone-300 mb-2 flex items-center gap-2"><TrendingUp className="h-5 w-5 text-amber-400" /> Percentil del Candidato</h4>
                                        <p className="text-stone-400 text-xs mb-2">Este candidato se encuentra por encima del <span className="font-bold text-amber-300">{percentile}%</span> de los demás candidatos evaluados.</p>
                                        <Progress value={percentile} className="h-2" />
                                    </div>
                                )}
                                {inconsistency_flag && (
                                    <TooltipProvider>
                                        <Tooltip>
                                            <TooltipTrigger asChild>
                                                <div className="md:col-span-2 mt-2">
                                                    <Badge variant="destructive" className="w-full justify-center cursor-help"><AlertOctagon className="mr-2 h-4 w-4"/> Bandera de Inconsistencia Detectada</Badge>
                                                </div>
                                            </TooltipTrigger>
                                            <TooltipContent>
                                                <p>La IA detectó posibles inconsistencias entre el CV y las respuestas del formulario.</p>
                                            </TooltipContent>
                                        </Tooltip>
                                    </TooltipProvider>
                                )}
                            </>
                        ) : <p className="text-sm text-stone-400 text-center md:col-span-2">Los puntajes detallados aparecerán aquí una vez finalizada la evaluación.</p>}
                    </CardContent>
                </Card>
            </div>
            <div className="space-y-6">
                <Card className="bg-stone-900 border-stone-800">
                    <CardHeader><CardTitle>Datos Rápidos</CardTitle></CardHeader>
                    <CardContent className="space-y-5">
                        <QuickInfoItem icon={<User className="h-5 w-5 text-amber-400" />} label="Sede Favorita" value={ubicacion_interes || 'No especificada'} />
                        <QuickInfoItem icon={<Clock className="h-5 w-5 text-amber-400" />} label="Disponibilidad" value={disponibilidad?.join(', ') || 'No especificada'} />
                        <QuickInfoItem icon={<DollarSign className="h-5 w-5 text-amber-400" />} label="Expectativa Salarial" value={formatCurrency(expectativa_salarial)} isBadge={true} />
                        <QuickInfoItem icon={<BrainCircuit className="h-5 w-5 text-amber-400" />} label="Última Evaluación IA" value={evaluado_at ? format(new Date(evaluado_at), "d MMM, yyyy", { locale: es }) : 'Pendiente'} />
                    </CardContent>
                </Card>
                <Card className="bg-stone-900 border-stone-800">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Edit className="h-5 w-5 text-amber-400" /> Seguimiento Manual</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <Label htmlFor="recruiter-status">Estado del Reclutador</Label>
                            <Select value={recruiter_status || 'Pendiente'} onValueChange={handleRecruiterStatusChange}>
                                <SelectTrigger id="recruiter-status" className="w-full mt-1">
                                    <SelectValue>
                                        <RecruiterStatusIcon status={recruiter_status || 'Pendiente'} />
                                    </SelectValue>
                                </SelectTrigger>
                                <SelectContent>
                                    {recruiterStatusOptions.map(opt => (
                                        <SelectItem key={opt} value={opt}><RecruiterStatusIcon status={opt} /></SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label htmlFor="recruiter-notes">Notas del Reclutador</Label>
                            <Textarea id="recruiter-notes" value={recruiterNotes} onChange={handleNotesChange} placeholder="Añade tus observaciones aquí..." className="mt-1" />
                            <div className="text-xs text-stone-500 mt-2 flex justify-between items-center">
                                <span>Última actualización: {format(new Date(updated_at), "d MMM, yyyy 'a las' HH:mm", { locale: es })}</span>
                                {isSavingNotes && <Loader2 className="h-4 w-4 animate-spin" />}
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-stone-900 border-stone-800">
                    <CardHeader><CardTitle className="flex items-center gap-2"><Briefcase className="h-5 w-5 text-amber-400" /> Puestos Sugeridos por IA</CardTitle></CardHeader>
                    <CardContent className="space-y-3">
                        {sugerencias_puesto && Array.isArray(sugerencias_puesto) && sugerencias_puesto.length > 0 ? (
                            sugerencias_puesto.map((sug, index) => (
                                <SuggestedPositionCard key={index} title={sug.title} score={sug.score} reasons={sug.reason} />
                            ))
                        ) : <p className="text-center text-stone-500 text-sm py-4">No hay sugerencias disponibles.</p>}
                    </CardContent>
                </Card>
            </div>
        </div>
         <div className="mt-6">
            <Button asChild variant="outline"><Link to="/candidates"><ArrowLeft className="mr-2 h-4 w-4" /> Volver a Candidatos</Link></Button>
        </div>
      </div>
    </PageTransition>
  );
};

export default CandidateDetailPage;