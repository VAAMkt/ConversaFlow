import React from 'react';
import { Helmet } from 'react-helmet-async';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, LineChart, Line } from 'recharts';
import { useDashboard } from '@/contexts/DashboardContext';
import { useNavigate } from 'react-router-dom';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Star, UserCheck, Loader2, Briefcase, BadgeCheck, FileText } from 'lucide-react';

const StatCard = ({ title, value, icon, description }) => (
    <Card className="bg-stone-900 border-stone-800 hover:bg-stone-800/50 transition-colors flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-stone-400">{title}</CardTitle>
            {icon}
        </CardHeader>
        <CardContent className="flex-grow">
            <div className="text-4xl font-bold text-amber-400">{value}</div>
            <p className="text-xs text-stone-500 h-8">{description}</p>
        </CardContent>
    </Card>
);

const COLORS = {
    'CONTRATAR': '#22c55e',
    'ENTREVISTAR': '#38bdf8',
    'REVISAR': '#facc15',
    'DESCARTAR': '#f87171',
    'PENDIENTE': '#a8a29e',
};

const DashboardPage = () => {
    const { loading, kpis, quality, funnel, weeklyApplications } = useDashboard();
    const navigate = useNavigate();

    if (loading) {
        return <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
    }
    
    const totalPostulados = funnel.postulados;
    
    const funnelDataPercentage = [
        { stage: 'Postulados', value: totalPostulados > 0 ? 100 : 0, color: '#f59e0b' },
        { stage: 'IA OK', value: totalPostulados > 0 ? (funnel.iaOk / totalPostulados) * 100 : 0, color: '#eab308' },
        { stage: 'Entrevistados', value: totalPostulados > 0 ? (funnel.entrevistados / totalPostulados) * 100 : 0, color: '#22c55e' },
        { stage: 'Contratados', value: totalPostulados > 0 ? (funnel.contratados / totalPostulados) * 100 : 0, color: '#06b6d4' },
    ];

    return (
        <PageTransition>
            <Helmet>
                <title>Dashboard | Reino del Talento</title>
                <meta name="description" content="Dashboard principal del sistema de reclutamiento de KINGPAPA." />
            </Helmet>
            <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <StatCard title="Promedio IA" value={kpis.avgIaScore} icon={<Star className="h-5 w-5 text-stone-500" />} description="Puntaje de candidatos evaluados" />
                    <StatCard title="Para Contratar" value={kpis.toHireCount} icon={<UserCheck className="h-5 w-5 text-stone-500" />} description="Recomendados por la IA" />
                    <StatCard title="Total Postulaciones" value={kpis.totalPostulados} icon={<FileText className="h-5 w-5 text-stone-500" />} description="En el período actual" />
                    <StatCard title="Tasa de Contratación" value={`${kpis.hiringRate}%`} icon={<BadgeCheck className="h-5 w-5 text-stone-500" />} description="Desde postulación a contratación" />
                </div>

                <div className="grid gap-6 lg:grid-cols-5">
                    <Card className="lg:col-span-3 bg-stone-900 border-stone-800">
                        <CardHeader><CardTitle className="text-stone-100">Distribución por Recomendación</CardTitle></CardHeader>
                        <CardContent className="h-[300px]">
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie data={quality.recommendationDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                                        {quality.recommendationDistribution.map((entry, index) => (<Cell key={`cell-${index}`} fill={COLORS[entry.name] || '#8884d8'} />))}
                                    </Pie>
                                    <Tooltip contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #44403c' }}/>
                                    <Legend/>
                                </PieChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                    <Card className="lg:col-span-2 bg-stone-900 border-stone-800">
                        <CardHeader><CardTitle className="text-stone-100">Calidad y Cultura</CardTitle></CardHeader>
                        <CardContent className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={Object.entries(quality.valueAverages).map(([name, value]) => ({ name, value }))} layout="vertical" margin={{ top: 5, right: 20, left: 80, bottom: 5 }}>
                                    <XAxis type="number" domain={[0, 25]} hide />
                                    <YAxis type="category" dataKey="name" width={80} tick={{ fill: '#a8a29e' }} tickLine={false} axisLine={false} />
                                    <Tooltip contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #44403c' }} cursor={{fill: 'rgba(255, 255, 255, 0.1)'}}/>
                                    <Bar dataKey="value" fill="#fbbf24" background={{ fill: '#292524' }} radius={[4, 4, 4, 4]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                </div>
                
                 <div className="grid gap-6 lg:grid-cols-2">
                    <Card className="bg-stone-900 border-stone-800">
                        <CardHeader><CardTitle className="text-stone-100">Top 5 Candidatos</CardTitle></CardHeader>
                        <CardContent>
                            <div className="space-y-2">
                                {quality.topCandidates.length > 0 ? quality.topCandidates.map(c => (
                                    <div key={c.id} className="flex items-center justify-between p-2 bg-stone-800/50 rounded-lg">
                                        <div className="flex items-center gap-3">
                                            <div className="flex-shrink-0 w-10 h-10 rounded-full bg-amber-400 flex items-center justify-center font-bold text-stone-900">{c.puntaje_total}</div>
                                            <div>
                                                <p className="font-semibold text-stone-100">{c.nombre}</p>
                                                <p className="text-xs text-stone-400">{c.ubicacion_interes || 'N/A'}</p>
                                            </div>
                                        </div>
                                        <Button size="sm" variant="ghost" onClick={() => navigate(`/candidates/${c.id}`)}>Ver Perfil</Button>
                                    </div>
                                )) : <p className="text-center text-stone-500 py-8">No hay candidatos evaluados.</p>}
                            </div>
                        </CardContent>
                    </Card>
                     <Card className="bg-stone-900 border-stone-800">
                        <CardHeader><CardTitle className="text-stone-100">Embudo de Pipeline (%)</CardTitle></CardHeader>
                        <CardContent className="h-[250px]">
                           <ResponsiveContainer width="100%" height="100%">
                                <BarChart layout="vertical" data={funnelDataPercentage} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                                    <XAxis type="number" domain={[0, 100]} stroke="#a8a29e" />
                                    <YAxis type="category" dataKey="stage" stroke="#a8a29e" />
                                    <Tooltip 
                                        formatter={(value) => `${value.toFixed(2)}%`}
                                        contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #44403c' }}
                                        cursor={{fill: 'rgba(255, 255, 255, 0.1)'}}
                                    />
                                    <Bar dataKey="value" background={{ fill: '#292524' }} radius={[4, 4, 4, 4]}>
                                        {funnelDataPercentage.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                </div>

                <Card className="bg-stone-900 border-stone-800">
                    <CardHeader>
                        <CardTitle className="text-stone-100">Postulaciones por Semana</CardTitle>
                    </CardHeader>
                    <CardContent className="h-[350px]">
                        <ResponsiveContainer>
                            <LineChart data={weeklyApplications}>
                                <XAxis dataKey="week" stroke="#a8a29e" />
                                <YAxis stroke="#a8a29e" />
                                <Tooltip contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #44403c' }} />
                                <Legend />
                                <Line type="monotone" dataKey="total_applications" name="Postulaciones" stroke="#fbbf24" strokeWidth={2} />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

            </div>
        </PageTransition>
    );
};

export default DashboardPage;