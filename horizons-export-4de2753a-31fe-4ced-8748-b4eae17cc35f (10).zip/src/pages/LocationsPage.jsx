import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useCandidates } from '@/contexts/CandidateContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from "@/components/ui/use-toast";
import { Plus, Edit, Trash2, Save, Loader2, Minus, Eye, Check, X } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";

const LocationForm = ({ location, onSave, onCancel, isSubmitting }) => {
  const [formData, setFormData] = useState(
    location?.id ? location : { name: '', ciudad: '', direccion: '', vacancies: 0, estado: 'activa' }
  );

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleVacanciesChange = (e) => {
    const value = parseInt(e.target.value, 10);
    setFormData(prev => ({ ...prev, vacancies: isNaN(value) ? 0 : Math.max(0, value) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nombre de la Sede</Label>
        <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required disabled={isSubmitting} />
      </div>
      <div>
        <Label htmlFor="ciudad">Ciudad</Label>
        <Input id="ciudad" name="ciudad" value={formData.ciudad} onChange={handleInputChange} required disabled={isSubmitting} />
      </div>
      <div>
        <Label htmlFor="direccion">Dirección</Label>
        <Input id="direccion" name="direccion" value={formData.direccion} onChange={handleInputChange} required disabled={isSubmitting} />
      </div>
      <div>
        <Label htmlFor="vacancies">Vacantes</Label>
        <Input id="vacancies" name="vacancies" type="number" min="0" value={formData.vacancies} onChange={handleVacanciesChange} required disabled={isSubmitting} />
      </div>
      <div className="flex items-center space-x-2">
        <Switch id="estado" checked={formData.estado === 'activa'} onCheckedChange={(checked) => setFormData(prev => ({ ...prev, estado: checked ? 'activa' : 'inactiva' }))} disabled={isSubmitting} />
        <Label htmlFor="estado">{formData.estado === 'activa' ? 'Activa' : 'Inactiva'}</Label>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting}>Cancelar</Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
          Guardar
        </Button>
      </DialogFooter>
    </form>
  );
};


const LocationsPage = () => {
  const { locations, loadingLocations, addLocation, updateLocation, deleteLocation, refreshLocations } = useCandidates();
  const { user } = useAuth();
  const isAdmin = user?.user_metadata?.role === 'admin';
  const [editingLocation, setEditingLocation] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSave = async (locationData) => {
    setIsSubmitting(true);
    try {
      if (locationData.id) {
        await updateLocation(locationData.id, {
          name: locationData.name,
          ciudad: locationData.ciudad,
          direccion: locationData.direccion,
          vacancies: locationData.vacancies,
          estado: locationData.estado,
        });
        toast({ title: '💾 Ubicación Actualizada', description: `Los datos de "${locationData.name}" han sido guardados.`, variant: "success" });
      } else {
        await addLocation({
          name: locationData.name,
          ciudad: locationData.ciudad,
          direccion: locationData.direccion,
          vacancies: locationData.vacancies,
          estado: locationData.estado,
        });
        toast({ title: '✅ Ubicación Añadida', description: `La ubicación "${locationData.name}" ha sido creada.`, variant: "success" });
      }
      setEditingLocation(null);
    } catch (error) {
      toast({ title: '❌ Error al guardar', description: error.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id, name) => {
    setIsSubmitting(true);
    try {
      await deleteLocation(id);
      toast({ title: '🗑️ Ubicación Eliminada', description: `La ubicación "${name}" ha sido eliminada.`, variant: "success" });
    } catch (error) {
      toast({ title: '❌ Error al eliminar', description: error.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateVacancy = async (location, increment) => {
    const newVacancies = Math.max(0, location.vacancies + increment);
    setIsSubmitting(true);
    try {
      await updateLocation(location.id, { vacancies: newVacancies });
      toast({ title: `Vacantes actualizadas`, description: `${location.name} ahora tiene ${newVacancies} vacantes.`, variant: 'success' });
    } catch (error) {
      toast({ title: '❌ Error al actualizar vacantes', description: error.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const toggleStatus = async (location) => {
    const newStatus = location.estado === 'activa' ? 'inactiva' : 'activa';
     setIsSubmitting(true);
    try {
      await updateLocation(location.id, { estado: newStatus });
      toast({ title: `Estado actualizado`, description: `${location.name} ahora está ${newStatus}.`, variant: 'success' });
    } catch (error) {
      toast({ title: '❌ Error al cambiar estado', description: error.message, variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleViewCandidates = (locationName) => {
    navigate(`/candidates?location=${encodeURIComponent(locationName)}`);
  };

  return (
    <PageTransition>
      <Helmet>
        <title>Ubicaciones | Reino del Talento</title>
        <meta name="description" content="Gestiona las ubicaciones y vacantes disponibles en KINGPAPA." />
      </Helmet>
      <div className="max-w-6xl mx-auto space-y-8">
        <Card className="bg-stone-900 border-stone-800">
          <CardHeader className="flex flex-row justify-between items-center">
            <div>
              <CardTitle className="text-2xl font-bold text-amber-400">Gestionar Ubicaciones</CardTitle>
              <CardDescription className="text-stone-400">Añade, edita o elimina las sedes de KINGPAPA.</CardDescription>
            </div>
            {isAdmin && (
              <Dialog open={!!editingLocation} onOpenChange={(open) => !open && setEditingLocation(null)}>
                <DialogTrigger asChild>
                  <Button onClick={() => setEditingLocation({})}>
                    <Plus className="mr-2 h-4 w-4" /> Añadir Ubicación
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingLocation?.id ? 'Editar' : 'Nueva'} Ubicación</DialogTitle>
                  </DialogHeader>
                  <LocationForm location={editingLocation} onSave={handleSave} onCancel={() => setEditingLocation(null)} isSubmitting={isSubmitting} />
                </DialogContent>
              </Dialog>
            )}
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-stone-700 hover:bg-stone-800/50">
                    <TableHead className="text-stone-300">Sede</TableHead>
                    <TableHead className="text-stone-300">Ciudad</TableHead>
                    <TableHead className="text-stone-300">Vacantes</TableHead>
                    <TableHead className="text-stone-300 text-center">Estado</TableHead>
                    <TableHead className="text-stone-300 text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loadingLocations ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-10"><Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" /></TableCell></TableRow>
                  ) : locations.map((loc) => (
                    <TableRow key={loc.id} className="border-stone-800">
                      <TableCell><span className="font-medium text-stone-100">{loc.name}</span></TableCell>
                      <TableCell className="text-stone-400">{loc.ciudad}</TableCell>
                      <TableCell className="text-stone-300">
                        <div className="flex items-center gap-2">
                           {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleUpdateVacancy(loc, -1)} disabled={isSubmitting}><Minus className="h-4 w-4" /></Button>}
                           <span className="font-bold text-lg w-4 text-center">{loc.vacancies}</span>
                           {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleUpdateVacancy(loc, 1)} disabled={isSubmitting}><Plus className="h-4 w-4" /></Button>}
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-2">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${loc.estado === 'activa' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                                {loc.estado === 'activa' ? 'Activa' : 'Inactiva'}
                            </span>
                            {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleStatus(loc)} disabled={isSubmitting}>{loc.estado === 'activa' ? <X className="h-4 w-4 text-red-500"/> : <Check className="h-4 w-4 text-green-500"/>}</Button>}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-1 justify-end">
                            <Button variant="ghost" size="icon" onClick={() => handleViewCandidates(loc.name)} title="Ver candidatos"><Eye className="h-4 w-4 text-stone-400" /></Button>
                            {isAdmin && <Button variant="ghost" size="icon" onClick={() => setEditingLocation(loc)} disabled={isSubmitting} title="Editar"><Edit className="h-4 w-4 text-stone-400" /></Button>}
                            {isAdmin && (
                              <Dialog>
                                <DialogTrigger asChild><Button variant="ghost" size="icon" disabled={isSubmitting} title="Eliminar"><Trash2 className="h-4 w-4 text-red-500" /></Button></DialogTrigger>
                                <DialogContent>
                                  <DialogHeader><DialogTitle>¿Estás seguro de eliminar esta ubicación?</DialogTitle><DialogDescription>Esta acción no se puede deshacer. Se eliminará permanentemente la ubicación "{loc.name}".</DialogDescription></DialogHeader>
                                  <DialogFooter>
                                    <DialogClose asChild><Button variant="outline">Cancelar</Button></DialogClose>
                                    <DialogClose asChild><Button variant="destructive" onClick={() => handleDelete(loc.id, loc.name)}>Sí, eliminar</Button></DialogClose>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                            )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {!loadingLocations && locations.length === 0 && (<p className="text-center py-8 text-stone-500">No hay ubicaciones creadas.</p>)}
            </div>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  );
};

export default LocationsPage;