import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast";
import { Webhook, Link2, Save, Loader2, Check } from 'lucide-react';
import ApiKeyManager from '@/components/ApiKeyInput';
import { useSettings } from '@/contexts/SettingsContext';

const WebhookUrlManager = ({ settingKey, title, description, placeholder }) => {
    const { settings, loading, updateSetting } = useSettings();
    const [url, setUrl] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [isSaved, setIsSaved] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        if (settings[settingKey]) {
            setUrl(settings[settingKey]);
        }
    }, [settings, settingKey]);

    const handleSave = async () => {
        setIsSaving(true);
        setIsSaved(false);
        try {
            if (url) new URL(url); // Basic URL validation, allow empty
        } catch (e) {
            toast({ variant: 'destructive', title: 'URL Inválida', description: 'Por favor, introduce una URL válida (ej. https://dominio.com).' });
            setIsSaving(false);
            return;
        }

        const { success, error } = await updateSetting(settingKey, url);
        if (success) {
            setIsSaved(true);
            toast({ variant: 'success', title: '¡Guardado!', description: `${title} actualizado.` });
            setTimeout(() => setIsSaved(false), 2000);
        } else {
            toast({ variant: 'destructive', title: 'Error al guardar', description: error });
        }
        setIsSaving(false);
    };

    return (
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6 p-4 rounded-lg bg-stone-900/50 border border-stone-800">
            <div className="flex-shrink-0">
                <Webhook className="h-8 w-8 text-amber-400" />
            </div>
            <div className="flex-grow">
                <h3 className="font-semibold text-stone-100">{title}</h3>
                <p className="text-sm text-stone-400 mt-1">{description}</p>
            </div>
            <div className="w-full sm:w-auto sm:min-w-[400px] flex items-center gap-2">
                <Label htmlFor={settingKey} className="sr-only">{title}</Label>
                <Input 
                    id={settingKey} 
                    placeholder={placeholder}
                    className="bg-stone-800 border-stone-700 placeholder:text-stone-500" 
                    value={loading ? 'Cargando...' : url}
                    onChange={(e) => setUrl(e.target.value)}
                    disabled={loading || isSaving}
                />
                <Button onClick={handleSave} disabled={isSaving || loading || url === settings[settingKey]}>
                    {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : isSaved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                    <span className="ml-2">{isSaved ? "Guardado" : "Guardar"}</span>
                </Button>
            </div>
        </div>
    );
};

const IntegrationsPage = () => {
    return (
        <PageTransition>
            <Helmet>
                <title>Integraciones | Reino del Talento</title>
                <meta name="description" content="Configura las integraciones con servicios externos como OpenAI y webhooks para automatizar tu proceso de reclutamiento." />
            </Helmet>
            <div className="max-w-5xl mx-auto space-y-8">
                <Card className="bg-stone-900 border-stone-800">
                    <CardHeader>
                        <CardTitle className="text-2xl font-bold text-amber-400">Configuración de Integraciones</CardTitle>
                        <CardDescription className="text-stone-400">
                            Conecta tus herramientas favoritas para potenciar el Reino del Talento.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <ApiKeyManager />
                        <WebhookUrlManager
                            settingKey="PUBLIC_POST_APPLY_REDIRECT_URL"
                            title="URL de Redirección tras Postulación"
                            description="La URL a la que se redirigirá al candidato tras enviar el formulario."
                            placeholder="https://kingpapa.co"
                        />
                        <WebhookUrlManager
                            settingKey="N8N_CV_EXTRACTION_WEBHOOK_URL"
                            title="Webhook de Extracción de CV (n8n)"
                            description="Se activa para analizar el CV de un candidato nuevo o al solicitar una actualización."
                            placeholder="URL del webhook de n8n"
                        />
                    </CardContent>
                </Card>
            </div>
        </PageTransition>
    );
};

export default IntegrationsPage;