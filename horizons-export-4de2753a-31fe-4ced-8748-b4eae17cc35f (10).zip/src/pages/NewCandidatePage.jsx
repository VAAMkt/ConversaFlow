import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet-async';
import { useCandidates } from '@/contexts/CandidateContext';
import { useSettings } from '@/contexts/SettingsContext';
import { useToast } from "@/components/ui/use-toast";
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Flame, Send, Loader2, CheckCircle, Copy, Gift } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { sanitizeFileName } from '@/lib/utils';

import FormSection from '@/components/new-candidate/FormSection';
import FileInput, { MAX_FILE_SIZE, ALLOWED_FILE_TYPES, ALLOWED_EXTENSIONS } from '@/components/new-candidate/FileInput';
import Questionnaire from '@/components/new-candidate/Questionnaire';
import { likertQuestions, mcqQuestions, tfQuestions, availabilityOptions, getShuffledQuestions } from '@/data/questionnaireData';

const NewCandidatePage = () => {
    const { locations } = useCandidates();
    const { settings } = useSettings();
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const [formData, setFormData] = useState({
        nombre: '', email: '', celular: '', ciudad: '', barrio: '', disponibilidad: [],
        tiene_experiencia_servicio: null, cv: null, mayor_logro: '',
        reto_dificil: '', tres_palabras: '', que_espera: '', valor_cercano: '',
        preferred_location_id: '', expectativa_salarial: '',
        likert_answers: {}, mcq_answers: {}, tf_answers: {}
    });
    const [errors, setErrors] = useState({});
    const [uploadProgress, setUploadProgress] = useState(0);
    const [shuffledQuestions, setShuffledQuestions] = useState({ shuffledLikert: [], shuffledMcq: [], shuffledTf: [] });
    const discountCode = "BIENVENIDOALREINO";

    useEffect(() => {
        setShuffledQuestions(getShuffledQuestions());
    }, []);
    
    const activeLocations = useMemo(() => locations.filter(loc => loc.estado === 'activa'), [locations]);

    const validateField = useCallback((name, value) => {
        let error = '';
        const requiredText = { nombre: 'Nombre completo', email: 'Email', celular: 'Celular', ciudad: 'Ciudad', barrio: 'Barrio' };
        if (requiredText[name] && !value) error = `El campo ${requiredText[name]} es obligatorio.`;

        if (name === 'email' && value && !/\S+@\S+\.\S+/.test(value)) error = 'Formato de email inválido.';
        if (name === 'celular' && value && !/^\d{7,10}$/.test(value)) error = 'El celular debe tener entre 7 y 10 dígitos.';
        if (name === 'nombre' && value.length > 100) error = 'El nombre no puede exceder los 100 caracteres.';
        if (name === 'preferred_location_id' && !value) error = 'Debes seleccionar una ubicación.';
        if (name === 'disponibilidad' && value.length === 0) error = 'Debes seleccionar al menos una disponibilidad.';
        if (name === 'cv' && !value) error = 'Debes adjuntar tu Hoja de Vida.';
        if (name.startsWith('lk_') && !value) error = "Debes responder todas las preguntas.";
        if (name.startsWith('mc_') && !value) error = "Debes responder todas las preguntas.";
        if (name.startsWith('tf_') && value === undefined) error = "Debes responder todas las preguntas.";

        setErrors(prev => ({ ...prev, [name]: error }));
        return !error;
    }, []);

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
        validateField(id, value);
    };

    const handleSelectChange = (id) => (value) => {
        setFormData(prev => ({ ...prev, [id]: value }));
        validateField(id, value);
    };
    
    const handleAvailabilityChange = (id) => {
        const newAvailability = formData.disponibilidad.includes(id) ? formData.disponibilidad.filter(item => item !== id) : [...formData.disponibilidad, id];
        setFormData(prev => ({ ...prev, disponibilidad: newAvailability }));
        validateField('disponibilidad', newAvailability);
    };

    const handleFileChange = (e) => {
        const { id, files } = e.target;
        const file = files[0];
        if (!file) return;

        let error = '';
        if (file.size > MAX_FILE_SIZE) error = 'El archivo no debe superar los 10MB.';
        else if (!ALLOWED_FILE_TYPES.some(type => file.type.startsWith(type)) && !ALLOWED_EXTENSIONS.some(ext => file.name.endsWith(ext))) error = 'Solo se permiten archivos PDF, DOC y DOCX.';

        if (error) {
            setErrors(prev => ({ ...prev, [id]: error }));
            e.target.value = '';
            return;
        }
        
        setFormData(prev => ({ ...prev, [id]: file }));
        setErrors(prev => ({ ...prev, [id]: '' }));
    };
    
    const handleRemoveFile = (id) => {
        setFormData(prev => ({...prev, [id]: null}));
        document.getElementById(id).value = '';
        validateField(id, null);
    };

    const handleQuestionnaireChange = (group, id, value) => {
        setFormData(prev => ({ ...prev, [group]: { ...prev[group], [id]: value } }));
        validateField(id, value);
    };

    const validateForm = useCallback(() => {
        const fieldsToValidate = ['nombre', 'email', 'celular', 'ciudad', 'barrio', 'disponibilidad', 'cv', 'preferred_location_id'];
        let allValid = true;
        
        fieldsToValidate.forEach(key => {
            if (!validateField(key, formData[key])) allValid = false;
        });

        likertQuestions.forEach(q => { if(formData.likert_answers[q.id] === undefined) { allValid = false; validateField(q.id, undefined); } });
        mcqQuestions.forEach(q => { if(formData.mcq_answers[q.id] === undefined) { allValid = false; validateField(q.id, undefined); } });
        tfQuestions.forEach(q => { if(formData.tf_answers[q.id] === undefined) { allValid = false; validateField(q.id, undefined); } });

        return allValid;
    }, [formData, validateField]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) {
            toast({ variant: "destructive", title: "Formulario incompleto", description: "Por favor, revisa todos los campos obligatorios." });
            return;
        }
        setIsSubmitting(true);
        try {
            const { data: existingCandidate } = await supabase.from('candidates').select('id, created_at').eq('email', formData.email).order('created_at', { ascending: false }).limit(1).maybeSingle();
            if (existingCandidate) {
                const sevenDaysAgo = new Date();
                sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
                if (new Date(existingCandidate.created_at) > sevenDaysAgo) {
                    throw new Error("Ya recibimos una postulación reciente con este email.");
                }
            }
            
            const sanitizedFileName = sanitizeFileName(formData.cv.name);
            const filePath = `public/${formData.email}_${Date.now()}_${sanitizedFileName}`;
            const { error: uploadError } = await supabase.storage.from('recruitment-cv').upload(filePath, formData.cv, { upsert: false, onUploadProgress: p => setUploadProgress((p.loaded/p.total)*100) });
            if (uploadError) throw new Error(`Error al subir CV: ${uploadError.message}`);
            
            const scores = { servicio: 0, palabra: 0, impacto: 0, mejora: 0 };
            likertQuestions.forEach(q => { scores[q.value] += q.reverse ? 6 - formData.likert_answers[q.id] : formData.likert_answers[q.id]; });
            mcqQuestions.forEach(q => { if (formData.mcq_answers[q.id] === q.correct) Object.entries(q.values).forEach(([k,v]) => scores[k]+=v); });
            tfQuestions.forEach(q => { if (formData.tf_answers[q.id] === q.correct) scores[q.value]++; });
            const inconsistency_flag = (6 - formData.likert_answers['lk_serv_atajo_rev'] >= 4 && 6 - formData.likert_answers['lk_palabra_compromisos_rev'] >= 4) || (6 - formData.likert_answers['lk_mejora_cambio_rev'] >= 4);

            const selectedLocation = locations.find(l => l.id === formData.preferred_location_id);
            const candidatePayload = { ...formData, cv_path: filePath, ubicacion_interes: selectedLocation?.name, expectativa_salarial: formData.expectativa_salarial ? Number(formData.expectativa_salarial) : null, tiene_experiencia_servicio: formData.tiene_experiencia_servicio === 'true', scores_raw: scores, inconsistency_flag };
            delete candidatePayload.cv;

            const { data: insertedCandidate, error: insertError } = await supabase.from('candidates').insert(candidatePayload).select().single();
            if (insertError) throw new Error(`Error al guardar postulación: ${insertError.message}`);

            const webhookUrl = settings.N8N_CV_EXTRACTION_WEBHOOK_URL;
            if (webhookUrl) {
                fetch(webhookUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ candidate_id: insertedCandidate.id }),
                }).catch(err => console.error("Error calling n8n webhook for new candidate:", err));
            } else {
                console.warn("N8N_CV_EXTRACTION_WEBHOOK_URL no está configurado. Saltando la extracción de CV.");
            }

            supabase.functions.invoke('evaluate-candidate', { body: { candidateId: insertedCandidate.id } }).catch(console.error);
            setShowSuccessModal(true);
        } catch (error) {
            toast({ variant: "destructive", title: "❌ Error en la postulación", description: error.message, });
        } finally {
            setIsSubmitting(false);
        }
    };
    
    useEffect(() => {
        let timer;
        if (showSuccessModal) {
            timer = setTimeout(() => { window.location.href = settings.PUBLIC_POST_APPLY_REDIRECT_URL || 'https://kingpapa.co'; }, 8000);
        }
        return () => clearTimeout(timer);
    }, [showSuccessModal, settings.PUBLIC_POST_APPLY_REDIRECT_URL]);

    const copyToClipboard = () => {
        navigator.clipboard.writeText(discountCode);
        toast({
            variant: "success",
            title: "¡Copiado!",
            description: "Código de descuento copiado al portapapeles.",
        });
    };

    return (
        <>
            <PageTransition>
                <Helmet> <title>Nueva Postulación | Reino del Talento</title> <meta name="description" content="Formulario de postulación para unirse al equipo de KINGPAPA." /> </Helmet>
                <div className="min-h-screen bg-background flex items-center justify-center p-4">
                    <div className="w-full max-w-3xl">
                        <div className="flex justify-center items-center gap-4 mb-6"> <Flame className="h-12 w-12 text-primary" /> <h1 className="text-4xl font-bold text-center text-foreground">Únete al Reino del Talento</h1> </div>
                        <Card className="bg-card border-border">
                            <CardHeader>
                                <CardTitle className="text-2xl text-foreground">Formulario de Postulación</CardTitle>
                                <CardDescription className="text-muted-foreground">Completa tus datos para ser parte de la familia KINGPAPA.</CardDescription>
                                <div className="mt-4 p-4 bg-secondary/50 border-l-4 border-primary rounded-r-lg">
                                    <p className="text-sm text-foreground">
                                        <strong className="font-semibold text-primary">Beneficio para la Banda KINGPAPA:</strong> por completar este formulario obtienes <strong className="font-bold">20% de descuento en toda la carta en tu próxima visita al Reino</strong>. 🎉
                                    </p>
                                    <p className="text-xs text-muted-foreground mt-1">*Beneficio exclusivo para colaboradores (“La Banda”).</p>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                                    <FormSection title="Datos Personales y Contacto">
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                          <div><Label htmlFor="nombre">Nombre Completo</Label><Input id="nombre" onBlur={handleInputChange} className={errors.nombre ? 'border-destructive' : ''} maxLength="100"/>{errors.nombre && <p className="text-sm text-destructive mt-1">{errors.nombre}</p>}</div>
                                          <div><Label htmlFor="email">Email</Label><Input id="email" type="email" onBlur={handleInputChange} className={errors.email ? 'border-destructive' : ''}/>{errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}</div>
                                          <div><Label htmlFor="celular">Celular</Label><Input id="celular" type="tel" onBlur={handleInputChange} className={errors.celular ? 'border-destructive' : ''} maxLength="10"/>{errors.celular && <p className="text-sm text-destructive mt-1">{errors.celular}</p>}</div>
                                          <div><Label htmlFor="ciudad">Ciudad</Label><Input id="ciudad" onBlur={handleInputChange} className={errors.ciudad ? 'border-destructive' : ''} maxLength="100"/>{errors.ciudad && <p className="text-sm text-destructive mt-1">{errors.ciudad}</p>}</div>
                                          <div><Label htmlFor="barrio">Barrio</Label><Input id="barrio" onBlur={handleInputChange} className={errors.barrio ? 'border-destructive' : ''} maxLength="100"/>{errors.barrio && <p className="text-sm text-destructive mt-1">{errors.barrio}</p>}</div>
                                      </div>
                                    </FormSection>

                                    <FormSection title="Hoja de Vida">
                                        <FileInput 
                                            id="cv" 
                                            label="Adjunta tu Hoja de Vida (PDF, DOC, DOCX, máx. 10MB)" 
                                            file={formData.cv} 
                                            progress={uploadProgress} 
                                            error={errors.cv}
                                            onFileChange={handleFileChange}
                                            onRemoveFile={handleRemoveFile}
                                        />
                                    </FormSection>

                                    <FormSection title="Cuéntanos más de ti">
                                        <div className="space-y-4">
                                            <div><Label htmlFor="mayor_logro">¿Cuál ha sido tu mayor logro personal o profesional? (máx. 500 caracteres)</Label><Textarea id="mayor_logro" maxLength="500" onChange={handleInputChange}/></div>
                                            <div><Label htmlFor="reto_dificil">Describe una situación en la que enfrentaste un reto difícil y cómo lo resolviste. (máx. 500 caracteres)</Label><Textarea id="reto_dificil" maxLength="500" onChange={handleInputChange}/></div>
                                            <div><Label htmlFor="tres_palabras">¿Cómo te describes en tres palabras? (máx. 100 caracteres)</Label><Textarea id="tres_palabras" maxLength="100" onChange={handleInputChange}/></div>
                                            <div><Label htmlFor="que_espera">¿Qué esperas aprender o lograr trabajando en KINGPAPA? (máx. 300 caracteres)</Label><Textarea id="que_espera" maxLength="300" onChange={handleInputChange}/></div>
                                            <div><Label htmlFor="valor_cercano">¿Cuál de nuestros valores sientes más cercano a ti y por qué? (máx. 300 caracteres)</Label><Textarea id="valor_cercano" maxLength="300" onChange={handleInputChange}/></div>
                                        </div>
                                    </FormSection>
                                    
                                    <FormSection title="Preferencia Laboral">
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                          <div>
                                              <Label htmlFor="preferred_location_id">Ubicación de Preferencia</Label>
                                              <Select onValueChange={handleSelectChange('preferred_location_id')}><SelectTrigger className={errors.preferred_location_id ? 'border-destructive' : ''}><SelectValue placeholder="Selecciona una sede activa" /></SelectTrigger><SelectContent>{activeLocations.map(loc => <SelectItem key={loc.id} value={loc.id}>{loc.ciudad} - {loc.name}</SelectItem>)}</SelectContent></Select>
                                              {errors.preferred_location_id && <p className="text-sm text-destructive mt-1">{errors.preferred_location_id}</p>}
                                          </div>
                                          <div>
                                              <Label>Disponibilidad horaria</Label>
                                              <div className="flex flex-col space-y-2 mt-2">{availabilityOptions.map(option => (<div key={option.id} className="flex items-center space-x-2"><Checkbox id={option.id} checked={formData.disponibilidad.includes(option.id)} onCheckedChange={() => handleAvailabilityChange(option.id)}/><Label htmlFor={option.id} className="font-normal">{option.label}</Label></div>))}</div>
                                              {errors.disponibilidad && <p className="text-sm text-destructive mt-1">{errors.disponibilidad}</p>}
                                          </div>
                                          <div>
                                              <Label>¿Tienes experiencia en servicio al cliente o gastronomía?</Label>
                                              <Select onValueChange={handleSelectChange('tiene_experiencia_servicio')}><SelectTrigger><SelectValue placeholder="Selecciona una opción" /></SelectTrigger><SelectContent><SelectItem value="true">Sí</SelectItem><SelectItem value="false">No</SelectItem></SelectContent></Select>
                                          </div>
                                          <div className="md:col-span-2"><Label htmlFor="expectativa_salarial">Expectativa Salarial Mensual (Opcional)</Label><Input id="expectativa_salarial" type="number" placeholder="Ej: 1500000" onChange={handleInputChange}/></div>
                                      </div>
                                    </FormSection>
                                    
                                    <FormSection title="Cuestionario de Estilo de Trabajo" description="Estas preguntas nos ayudan a entender mejor tu forma de trabajar. No hay respuestas correctas o incorrectas, solo sé honesto/a.">
                                        <Questionnaire 
                                            questions={shuffledQuestions}
                                            answers={formData}
                                            errors={errors}
                                            onAnswer={{
                                                onLikertChange: (id, val) => handleQuestionnaireChange('likert_answers', id, val),
                                                onMcqChange: (id, val) => handleQuestionnaireChange('mcq_answers', id, val),
                                                onTfChange: (id, val) => handleQuestionnaireChange('tf_answers', id, val),
                                            }}
                                        />
                                    </FormSection>

                                    <div className="pt-6 flex justify-end"><Button type="submit" size="lg" disabled={isSubmitting}>{isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Procesando...</> : <><Send className="mr-2 h-4 w-4" /> Enviar Postulación</>}</Button></div>
                                </form>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </PageTransition>
            <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
                <DialogContent className="sm:max-w-md bg-card border-border text-center" onEscapeKeyDown={() => window.location.href = settings.PUBLIC_POST_APPLY_REDIRECT_URL || 'https://kingpapa.co'}>
                    <DialogHeader>
                        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/50">
                             <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
                        </div>
                        <DialogTitle className="text-2xl font-bold mt-4 text-primary">¡Postulación enviada!</DialogTitle>
                        <DialogDescription className="text-muted-foreground mt-2">Tu postulación ha sido recibida y será analizada por nuestro sistema inteligente.</DialogDescription>
                    </DialogHeader>
                    <div className="my-6 p-4 rounded-lg bg-secondary/50 border border-dashed border-primary/50">
                        <p className="text-sm text-foreground mb-2">Presenta este código en caja para tu <strong className="font-bold text-primary">20% de descuento</strong>:</p>
                        <div className="flex items-center justify-center gap-2">
                             <p className="text-2xl font-mono font-bold tracking-widest text-primary bg-background/50 px-4 py-1 rounded-md">{discountCode}</p>
                             <Button variant="ghost" size="icon" onClick={copyToClipboard}>
                                <Copy className="h-5 w-5" />
                                <span className="sr-only">Copiar código</span>
                             </Button>
                        </div>
                    </div>
                    <p className="text-xs text-stone-400">Serás redirigido en unos segundos. ¡Bienvenido al proceso de selección del Reino!</p>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default NewCandidatePage;