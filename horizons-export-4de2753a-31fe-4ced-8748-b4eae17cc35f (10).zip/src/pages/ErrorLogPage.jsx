import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import PageTransition from '@/components/PageTransition';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, AlertTriangle, Info, ShieldAlert as ShieldWarning } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const SeverityBadge = ({ severity }) => {
    switch (severity) {
        case 'error':
            return <Badge variant="destructive" className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" /> Error</Badge>;
        case 'warning':
            return <Badge variant="secondary" className="flex items-center gap-1 bg-yellow-500/20 text-yellow-400"><ShieldWarning className="h-3 w-3" /> Warning</Badge>;
        case 'info':
            return <Badge variant="default" className="flex items-center gap-1 bg-sky-500/20 text-sky-400"><Info className="h-3 w-3" /> Info</Badge>;
        default:
            return <Badge>{severity}</Badge>;
    }
};

const ErrorLogPage = () => {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLogs = async () => {
            setLoading(true);
            try {
                const { data, error } = await supabase
                    .from('error_logs')
                    .select('*, candidate:candidates(id, nombre)')
                    .order('created_at', { ascending: false })
                    .limit(100);
                if (error) throw error;
                setLogs(data);
            } catch (error) {
                console.error("Error fetching logs:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchLogs();
    }, []);

    return (
        <PageTransition>
            <Helmet>
                <title>Registro de Errores | Reino del Talento</title>
                <meta name="description" content="Visualización de errores y eventos del sistema." />
            </Helmet>
            <Card className="bg-stone-900 border-stone-800">
                <CardHeader>
                    <CardTitle>Registro de Errores y Eventos</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="border-stone-700 hover:bg-stone-800/50">
                                    <TableHead>Fecha</TableHead>
                                    <TableHead>Severidad</TableHead>
                                    <TableHead>Etapa</TableHead>
                                    <TableHead>Mensaje</TableHead>
                                    <TableHead>Candidato</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow><TableCell colSpan="5" className="text-center py-10"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
                                ) : logs.length > 0 ? (
                                    logs.map(log => (
                                        <TableRow key={log.id} className="border-stone-800">
                                            <TableCell className="text-stone-400">{format(new Date(log.created_at), "Pp", { locale: es })}</TableCell>
                                            <TableCell><SeverityBadge severity={log.severity} /></TableCell>
                                            <TableCell className="font-mono text-xs">{log.stage}</TableCell>
                                            <TableCell className="text-stone-300">{log.message}</TableCell>
                                            <TableCell className="text-stone-400">{log.candidate?.nombre || 'N/A'}</TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow><TableCell colSpan="5" className="text-center py-10">No hay registros de errores.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </PageTransition>
    );
};

export default ErrorLogPage;