import React from 'react';
import { Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { ErrorBoundary } from 'react-error-boundary';
import Layout from '@/components/layout/Layout';
import DashboardPage from '@/pages/DashboardPage';
import CandidatesPage from '@/pages/CandidatesPage';
import LocationsPage from '@/pages/LocationsPage';
import IntegrationsPage from '@/pages/IntegrationsPage';
import NewCandidatePage from '@/pages/NewCandidatePage';
import CandidateDetailPage from '@/pages/CandidateDetailPage';
import LoginPage from '@/pages/LoginPage';
import UsersPage from '@/pages/UsersPage';
import ErrorLogPage from '@/pages/ErrorLogPage';
import TalentLandingPage from '@/pages/TalentLandingPage';
import { CandidateProvider } from '@/contexts/CandidateContext';
import { DashboardProvider } from '@/contexts/DashboardContext';
import { SettingsProvider } from '@/contexts/SettingsContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Toaster } from '@/components/ui/toaster';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

const RedirectComponent = ({ to }) => {
  window.location.href = to;
  return null;
};

const ErrorFallback = ({ error, resetErrorBoundary }) => {
  console.error("Error de renderizado:", error);
  return (
    <div className="flex flex-col justify-center items-center h-screen bg-background text-foreground" role="alert">
      <h2 className="text-2xl font-bold text-destructive mb-4">Algo salió mal</h2>
      <p className="mb-6">No se pudo cargar el componente. Por favor, inténtalo de nuevo.</p>
      <Button onClick={resetErrorBoundary}>Reintentar</Button>
    </div>
  );
};

function AppContent() {
  const location = useLocation();
  const { session, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg">Cargando el Reino...</p>
      </div>
    );
  }

  return (
    <SettingsProvider>
      <CandidateProvider>
        <DashboardProvider>
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route path="/postula" element={<NewCandidatePage />} />
              <Route path="/login" element={!session ? <LoginPage /> : <Navigate to="/" replace />} />
              <Route path="/talento" element={<TalentLandingPage />} />
              
              {/* Redirects */}
              <Route path="/aplica" element={<RedirectComponent to="https://kingpapa.online/postula" />} />
              <Route path="/apply" element={<RedirectComponent to="https://kingpapa.online/postula" />} />
              <Route path="/postulate" element={<RedirectComponent to="https://kingpapa.online/postula" />} />

              <Route 
                path="/" 
                element={
                  <ProtectedRoute>
                    <Layout />
                  </ProtectedRoute>
                }
              >
                <Route index element={<DashboardPage />} />
                <Route path="dashboard" element={<Navigate to="/" replace />} />
                <Route path="candidates" element={<CandidatesPage />} />
                <Route path="candidates/:id" element={<CandidateDetailPage />} />
                <Route path="locations" element={<LocationsPage />} />
                
                <Route path="errors" element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <ErrorLogPage />
                  </ProtectedRoute>
                } />
                <Route path="integrations" element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <IntegrationsPage />
                  </ProtectedRoute>
                } />
                <Route path="users" element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <UsersPage />
                  </ProtectedRoute>
                } />
              </Route>
            </Routes>
          </AnimatePresence>
          <Toaster />
        </DashboardProvider>
      </CandidateProvider>
    </SettingsProvider>
  );
}

function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback} onReset={() => window.location.reload()}>
      <AppContent />
    </ErrorBoundary>
  );
}

export default App;