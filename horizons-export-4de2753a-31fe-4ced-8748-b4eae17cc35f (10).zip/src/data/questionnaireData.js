export const likertQuestions = [
    { id: 'lk_serv_centro', text: 'Antes de proponer una solución, me aseguro de haber entendido exactamente lo que el cliente necesita.', reverse: false, value: 'servicio' },
    { id: 'lk_palabra_protocolo', text: 'Incluso cuando hay prisa, siempre sigo el procedimiento acordado al pie de la letra.', reverse: false, value: 'palabra' },
    { id: 'lk_impacto_equipo', text: 'Cuando noto que un compañero de equipo está atascado, le ofrezco ayuda aunque no me la pida directamente.', reverse: false, value: 'impacto' },
    { id: 'lk_mejora_micro', text: 'Cada semana, intento probar una forma ligeramente distinta de hacer mi trabajo para ver si puedo mejorarlo en un 1%.', reverse: false, value: 'mejora' },
    { id: 'lk_serv_atajo_rev', text: 'Si el cliente parece estar tranquilo y satisfecho, considero válido omitir algunos pasos del protocolo de servicio para agilizar.', reverse: true, value: 'servicio' },
    { id: 'lk_palabra_compromisos_rev', text: 'Si las circunstancias cambian de forma inesperada, es aceptable no cumplir con todos los compromisos que había prometido.', reverse: true, value: 'palabra' },
    { id: 'lk_impacto_credito', text: 'Tengo el hábito de reconocer públicamente la contribución de otros en los logros del equipo.', reverse: false, value: 'impacto' },
    { id: 'lk_mejora_cambio_rev', text: 'Prefiero no cambiar mi forma de trabajar hasta que la jefatura lo solicite y documente oficialmente.', reverse: true, value: 'mejora' },
];

export const mcqQuestions = [
    { id: 'mc_pedido_equivocado', text: 'Un cliente está visiblemente molesto porque su pedido es incorrecto. ¿Qué haces?', options: ['A: Me disculpo, repongo su pedido con prioridad, le explico los pasos que tomaré y registro la causa del error para que no vuelva a pasar.', 'B: Le ofrezco un descuento en su próxima compra sin revisar el problema.', 'C: Le explico que la culpa fue de un compañero de otra área.', 'D: Lo derivo inmediatamente a mi supervisor sin darle más explicaciones.'], correct: 'A', values: {servicio: 3} },
    { id: 'mc_descuadre_caja', text: 'Al final de tu turno, hay un pequeño descuadre en la caja. ¿Cuál es tu reacción?', options: ['A: Reporto la diferencia inmediatamente a mi superior, reviso los últimos movimientos usando el checklist y colaboro para identificar la causa y prevenirla a futuro.', 'B: Pienso en cubrirlo con mi propio dinero al día siguiente para evitar problemas.', 'C: Lo ignoro, es una cantidad pequeña y probablemente se arregle sola.', 'D: Dejo una nota para que la persona del siguiente turno lo resuelva.'], correct: 'A', values: {palabra: 2, impacto: 1} },
    { id: 'mc_turno_pico', text: 'Estás en medio de un pico de trabajo con muchas tareas urgentes. ¿Cómo te organizas?', options: ['A: Identifico las tareas más críticas que impactan al cliente y al equipo, las priorizo y comunico a mis compañeros en qué estoy trabajando.', 'B: Me enfoco únicamente en mis tareas asignadas, una por una.', 'C: Espero a que mi jefe me diga qué hacer primero.', 'D: Me voy a mi descanso programado sin avisar sobre el estado de mis pendientes.'], correct: 'A', values: {impacto: 3} },
    { id: 'mc_proceso_nuevo', text: 'La empresa introduce un nuevo proceso, pero las instrucciones no son muy claras. ¿Qué haces?', options: ['A: Pruebo el nuevo proceso en una tarea pequeña, mido el resultado, documento lo que funcionó y lo que no, y lo comparto como sugerencia.', 'B: Sigo haciendo las cosas como siempre hasta que me obliguen a cambiar.', 'C: Cambio todo mi flujo de trabajo de una vez sin comunicar a nadie.', 'D: Copio lo que veo que hacen otros, sin medir si es más o menos eficiente.'], correct: 'A', values: {mejora: 3} },
];

export const tfQuestions = [
    { id: 'tf_registro_errores', text: 'Llevo un registro personal de cuándo me equivoco y qué hice para corregirlo.', correct: true, value: 'palabra' },
    { id: 'tf_feedback', text: 'Acostumbro a pedir retroalimentación a mis compañeros o supervisor al terminar turnos clave.', correct: true, value: 'mejora' },
    { id: 'tf_excusas_rev', text: 'Cuando algo sale mal, usualmente es por culpa de factores que estaban fuera de mi control.', correct: false, value: 'palabra' },
    { id: 'tf_cliente_enojo', text: 'Soy capaz de bajar el tono de una conversación difícil con un cliente y aclarar un plan de acción.', correct: true, value: 'servicio' },
    { id: 'tf_compartir_buenas', text: 'Cuando descubro una mejora que me funcionó, la comparto activamente con el resto del equipo.', correct: true, value: 'impacto' },
    { id: 'tf_atajo_rev', text: 'Si la mayoría de mis compañeros toman un atajo en un proceso, yo también lo hago para no quedarme atrás.', correct: false, value: 'palabra' },
];

export const availabilityOptions = [ 
    { id: 'Tiempo completo', label: 'Tiempo completo' }, 
    { id: 'Media jornada', label: 'Media jornada' }, 
    { id: 'Fines de semana', label: 'Fines de semana' }, 
    { id: 'Por turnos rotativos', label: 'Por turnos rotativos' } 
];

const shuffleArray = (array) => [...array].sort(() => Math.random() - 0.5);

export const getShuffledQuestions = () => ({
    shuffledLikert: shuffleArray(likertQuestions),
    shuffledMcq: shuffleArray(mcqQuestions),
    shuffledTf: shuffleArray(tfQuestions),
});