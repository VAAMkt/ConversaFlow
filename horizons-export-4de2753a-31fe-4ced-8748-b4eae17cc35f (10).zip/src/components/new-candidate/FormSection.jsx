import React from 'react';

const FormSection = ({ title, children, description }) => (
    <div className="space-y-4 py-6 border-b border-border last:border-b-0">
        <h3 className="text-lg font-semibold text-primary">{title}</h3>
        {description && <p className="text-sm text-muted-foreground">{description}</p>}
        {children}
    </div>
);

export default FormSection;