import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { File, Check, Trash2 } from 'lucide-react';

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
export const ALLOWED_FILE_TYPES = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
export const ALLOWED_EXTENSIONS = ['.pdf', '.doc', '.docx'];

const FileInput = ({ id, label, file, progress, error, onFileChange, onRemoveFile }) => (
    <div>
        <Label htmlFor={id}>{label}</Label>
        {!file ? (
            <>
                <Input id={id} type="file" onChange={onFileChange} accept={ALLOWED_EXTENSIONS.join(',')} className={`file:text-primary ${error ? 'border-destructive' : ''}`} />
                {error && <p className="text-sm text-destructive mt-1">{error}</p>}
            </>
        ) : (
            <div className="mt-2 p-3 bg-stone-800 rounded-md border border-stone-700">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-stone-300 overflow-hidden">
                        <File className="h-5 w-5 flex-shrink-0" />
                        <span className="truncate">{file.name}</span>
                    </div>
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => onRemoveFile(id)}><Trash2 className="h-4 w-4" /></Button>
                </div>
                {progress > 0 && progress < 100 && <Progress value={progress} className="h-2 mt-2" />}
                {progress === 100 && <div className="flex items-center gap-2 mt-2 text-green-400 text-sm"><Check className="h-4 w-4" />Subido</div>}
            </div>
        )}
    </div>
);

export default FileInput;