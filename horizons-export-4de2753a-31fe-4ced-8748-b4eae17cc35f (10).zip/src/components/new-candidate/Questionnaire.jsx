import React from 'react';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';

const Questionnaire = ({ questions, answers, errors, onAnswer, type }) => {
    const { shuffledLikert, shuffledMcq, shuffledTf } = questions;
    const { likert_answers, mcq_answers, tf_answers } = answers;
    const { onLikertChange, onMcqChange, onTfChange } = onAnswer;

    return (
        <>
            {/* Likert Scale */}
            <div className="space-y-4">
                <h4 className="font-semibold text-foreground">Evalúa de 1 (Totalmente en desacuerdo) a 5 (Totalmente de acuerdo):</h4>
                {shuffledLikert.map((q, i) => (
                    <div key={q.id} className="p-4 bg-card-dark rounded-lg">
                        <Label className="font-normal">{i + 1}. {q.text}</Label>
                        <div className="flex justify-between items-center mt-2">
                            {[1, 2, 3, 4, 5].map(v => <Button key={v} type="button" variant={likert_answers[q.id] === v ? 'default' : 'outline'} size="sm" onClick={() => onLikertChange(q.id, v)} className="rounded-full h-8 w-8 p-0">{v}</Button>)}
                        </div>
                        {errors[q.id] && <p className="text-sm text-destructive mt-1">{errors[q.id]}</p>}
                    </div>
                ))}
            </div>
            {/* Multiple Choice */}
            <div className="space-y-4">
                <h4 className="font-semibold text-foreground">Elige la opción que mejor te representa en cada escenario:</h4>
                {shuffledMcq.map((q, i) => (
                    <div key={q.id} className="p-4 bg-card-dark rounded-lg">
                        <Label className="font-normal">{i + 1}. {q.text}</Label>
                        <div className="flex flex-col space-y-2 mt-2">
                          {q.options.map(opt => <Button key={opt} type="button" variant={mcq_answers[q.id] === opt.charAt(0) ? 'secondary' : 'ghost'} className="justify-start text-left h-auto" onClick={() => onMcqChange(q.id, opt.charAt(0))}>{opt}</Button>)}
                        </div>
                         {errors[q.id] && <p className="text-sm text-destructive mt-1">{errors[q.id]}</p>}
                    </div>
                ))}
            </div>
            {/* True/False */}
            <div className="space-y-4">
                <h4 className="font-semibold text-foreground">Indica si las siguientes afirmaciones son Verdaderas o Falsas para ti:</h4>
                {shuffledTf.map((q, i) => (
                    <div key={q.id} className="p-4 bg-card-dark rounded-lg">
                        <Label className="font-normal">{i + 1}. {q.text}</Label>
                        <div className="flex gap-4 mt-2">
                            <Button type="button" variant={tf_answers[q.id] === true ? 'secondary' : 'ghost'} onClick={() => onTfChange(q.id, true)}>Verdadero</Button>
                            <Button type="button" variant={tf_answers[q.id] === false ? 'secondary' : 'ghost'} onClick={() => onTfChange(q.id, false)}>Falso</Button>
                        </div>
                        {errors[q.id] && <p className="text-sm text-destructive mt-1">{errors[q.id]}</p>}
                    </div>
                ))}
            </div>
        </>
    );
};

export default Questionnaire;