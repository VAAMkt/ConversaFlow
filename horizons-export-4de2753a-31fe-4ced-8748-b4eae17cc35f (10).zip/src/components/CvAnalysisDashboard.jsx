import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, FileText, Tag, Briefcase, Loader2, AlertTriangle, CheckCircle } from 'lucide-react';

const KEYWORD_SIGNALS = {
  'Liderazgo': ['líder', 'liderazgo', 'supervisor', 'coordinador', 'gerente', 'jefe', 'encargado'],
  'Servicio al Cliente': ['cliente', 'atención', 'servicio', 'mesero', 'cajero', 'anfitrión'],
  'Cocina': ['cocina', 'chef', 'cocinero', 'parrilla', 'frituras', 'preparación', 'sous chef'],
  'Inventarios': ['inventario', 'stock', 'almacén', 'bodega', 'pedidos', 'proveedores'],
  'Administración': ['administración', 'admin', 'cierre de caja', 'reportes', 'costos'],
  'Ventas': ['ventas', 'vendedor', 'metas', 'comisiones'],
  'Bilingüe': ['inglés', 'bilingüe', 'english', 'toefl'],
};

const JOB_SUGGESTIONS = [
    { title: 'Gerente de Tienda', keywords: ['gerente', 'supervisor', 'liderazgo', 'administración'] },
    { title: 'Líder de Turno', keywords: ['líder', 'coordinador', 'supervisor'] },
    { title: 'Cocinero Experto', keywords: ['cocina', 'chef', 'parrilla'] },
    { title: 'Experto en Servicio', keywords: ['servicio al cliente', 'mesero', 'cajero'] },
    { title: 'Operario de Cocina', keywords: ['cocina', 'preparación'] },
];

const CvAnalysisDashboard = ({ candidate }) => {
  const [showFullSummary, setShowFullSummary] = useState(false);

  const cvStatus = useMemo(() => {
    if (candidate.cv_extraction_status === 'error') return { key: 'error', text: 'Error en la última extracción', icon: <AlertTriangle className="h-4 w-4 text-red-400" /> };
    if (candidate.cv_text) return { key: 'ok', text: `Analizado por última vez: ${new Date(candidate.last_extraction_at).toLocaleString()}`, icon: <CheckCircle className="h-4 w-4 text-green-400" /> };
    return { key: 'pending', text: 'CV pendiente de análisis', icon: <Loader2 className="h-4 w-4 text-yellow-400" /> };
  }, [candidate.cv_text, candidate.cv_extraction_status, candidate.last_extraction_at]);

  const detectedSignals = useMemo(() => {
    if (!candidate.cv_text) return [];
    const signals = new Set();
    const text = candidate.cv_text.toLowerCase();
    for (const [signal, keywords] of Object.entries(KEYWORD_SIGNALS)) {
      if (keywords.some(kw => text.includes(kw))) {
        signals.add(signal);
      }
    }
    return Array.from(signals);
  }, [candidate.cv_text]);

  const suggestedPositions = useMemo(() => {
    if (!candidate.cv_text) return [];
    const suggestions = [];
    const text = candidate.cv_text.toLowerCase();

    for (const job of JOB_SUGGESTIONS) {
        if (job.keywords.some(kw => text.includes(kw))) {
            suggestions.push({ title: job.title, reason: `Habilidades detectadas en ${job.keywords[0]}.` });
        }
    }
    return suggestions.slice(0, 4);
  }, [candidate.cv_text]);

  const summary = candidate.cv_text || "No hay un resumen de CV disponible. Actualiza y analiza para generarlo.";
  const isLongSummary = summary.length > 300;

  return (
    <Card className="bg-stone-900 border-stone-800">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center gap-2 text-xl text-stone-100">
              <Brain className="h-6 w-6 text-amber-400" />
              Análisis Profundo del Perfil
            </CardTitle>
            <CardDescription className="flex items-center gap-2 pt-2 text-sm text-stone-400">
              {cvStatus.icon} {cvStatus.text}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h4 className="font-semibold text-stone-300 flex items-center gap-2 mb-2"><FileText className="h-5 w-5" /> Resumen de CV</h4>
          <p className="text-stone-400 text-sm leading-relaxed">
            {isLongSummary && !showFullSummary ? `${summary.substring(0, 300)}...` : summary}
          </p>
          {isLongSummary && (
            <Button variant="link" className="p-0 h-auto text-amber-400" onClick={() => setShowFullSummary(!showFullSummary)}>
              {showFullSummary ? 'Ver menos' : 'Ver más'}
            </Button>
          )}
        </div>

        {detectedSignals.length > 0 && (
          <div>
            <h4 className="font-semibold text-stone-300 flex items-center gap-2 mb-3"><Tag className="h-5 w-5" /> Señales Detectadas</h4>
            <div className="flex flex-wrap gap-2">
              {detectedSignals.map(signal => (
                <Badge key={signal} variant="secondary" className="bg-stone-700 text-stone-200 border-stone-600">{signal}</Badge>
              ))}
            </div>
          </div>
        )}

        {suggestedPositions.length > 0 && (
          <div>
            <h4 className="font-semibold text-stone-300 flex items-center gap-2 mb-3"><Briefcase className="h-5 w-5" /> Puestos Sugeridos</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {suggestedPositions.map(pos => (
                <div key={pos.title} className="bg-stone-800/50 p-4 rounded-lg border border-stone-700">
                  <p className="font-bold text-amber-400">{pos.title}</p>
                  <p className="text-xs text-stone-400 mt-1">{pos.reason}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CvAnalysisDashboard;