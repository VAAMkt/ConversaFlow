import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Users, MapPin, Settings, Flame, ShieldAlert, UserCog } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const Sidebar = () => {
    const { user } = useAuth();
    const isAdmin = user?.user_metadata?.role === 'admin';

    const navItems = [
        { to: '/', icon: <Home className="h-5 w-5" />, text: 'Dashboard' },
        { to: '/candidates', icon: <Users className="h-5 w-5" />, text: 'Candidatos' },
        { to: '/locations', icon: <MapPin className="h-5 w-5" />, text: 'Sedes' },
    ];

    const adminNavItems = [
        { to: '/errors', icon: <ShieldAlert className="h-5 w-5" />, text: 'Errores' },
        { to: '/users', icon: <UserCog className="h-5 w-5" />, text: 'Usuarios' },
        { to: '/integrations', icon: <Settings className="h-5 w-5" />, text: 'Integraciones' },
    ];

    const getNavLinkClass = ({ isActive }) =>
        `flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
            isActive
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
        }`;

    return (
        <aside className="w-64 bg-card border-r border-border flex flex-col h-full">
            <div className="flex items-center justify-center h-20 border-b border-border flex-shrink-0">
                <Flame className="h-8 w-8 text-primary" />
                <span className="ml-3 text-xl font-bold text-foreground">Reino del Talento</span>
            </div>
            <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
                {navItems.map((item) => (
                    <NavLink key={item.to} to={item.to} className={getNavLinkClass} end>
                        {item.icon}
                        <span className="ml-3">{item.text}</span>
                    </NavLink>
                ))}
                {isAdmin && (
                    <>
                        <div className="px-4 pt-6 pb-2">
                            <span className="text-xs font-semibold text-muted-foreground uppercase">Admin</span>
                        </div>
                        {adminNavItems.map((item) => (
                            <NavLink key={item.to} to={item.to} className={getNavLinkClass}>
                                {item.icon}
                                <span className="ml-3">{item.text}</span>
                            </NavLink>
                        ))}
                    </>
                )}
            </nav>
        </aside>
    );
};

export default Sidebar;