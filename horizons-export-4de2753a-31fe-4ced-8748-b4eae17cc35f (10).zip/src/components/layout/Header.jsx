import React from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { LogOut, Menu, ExternalLink } from 'lucide-react';
import { useLocation, Link } from 'react-router-dom';

const Header = ({ onMenuClick }) => {
  const { user, signOut } = useAuth();
  const location = useLocation();

  const getTitle = () => {
    const path = location.pathname.split('/')[1];
    switch (path) {
      case '': return 'Dashboard del Reino del Talento 👑';
      case 'candidates': return 'Candidatos';
      case 'locations': return 'Sedes';
      case 'errors': return 'Logs de Errores';
      case 'users': return 'Gestión de Usuarios';
      case 'integrations': return 'Integraciones';
      default: return 'Reino del Talento';
    }
  };

  return (
    <header className="flex items-center justify-between h-20 px-4 sm:px-6 lg:px-8 bg-card border-b border-border flex-shrink-0">
      <div className="flex items-center">
        <Button variant="ghost" size="icon" className="md:hidden mr-4" onClick={onMenuClick}>
          <Menu className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-semibold text-foreground">{getTitle()}</h1>
      </div>
      <div className="flex items-center space-x-4">
        <div className="hidden sm:flex items-center space-x-3 text-xs">
          <Link to="/talento" className="text-muted-foreground hover:text-primary transition-colors" data-testid="dash-link-talento" aria-label="Ver landing de Talento">
            Talento (pública)
          </Link>
          <a href="https://kingpapa.online/postula" className="flex items-center text-muted-foreground hover:text-primary transition-colors" data-testid="dash-link-postula" aria-label="Ir al formulario de postulación">
            Postular <ExternalLink className="h-3 w-3 ml-1" />
          </a>
        </div>
        <span className="text-sm text-muted-foreground hidden sm:inline border-l border-border pl-4">
          {user?.email}
        </span>
        <Button variant="ghost" size="icon" onClick={signOut}>
          <LogOut className="h-5 w-5" />
          <span className="sr-only">Cerrar sesión</span>
        </Button>
      </div>
    </header>
  );
};

export default Header;