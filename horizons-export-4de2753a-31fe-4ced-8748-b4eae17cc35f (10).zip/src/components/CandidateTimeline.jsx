import React from 'react';
    import { CheckCircle, Circle, MoreHorizontal } from 'lucide-react';
    import { cn } from '@/lib/utils';
    
    const TimelineItem = ({ step, date, isCompleted, isLast }) => {
        const formatDate = (d) => {
            if (!d) return null;
            return new Date(d).toLocaleDateString('es-CO', { day: 'numeric', month: 'short', year: 'numeric' });
        };
    
        return (
            <div className="relative flex items-start">
                <div className="flex flex-col items-center mr-4">
                    {isCompleted ? (
                        <CheckCircle className="h-6 w-6 text-green-500" />
                    ) : (
                        <Circle className="h-6 w-6 text-stone-600" />
                    )}
                    {!isLast && (
                        <div className={cn("w-px h-16 mt-1", isCompleted ? 'bg-green-500' : 'bg-stone-600')}></div>
                    )}
                </div>
                <div className="pt-0.5">
                    <p className={cn("font-semibold", isCompleted ? "text-stone-100" : "text-stone-500")}>{step}</p>
                    {isCompleted && date && (
                        <p className="text-xs text-stone-400">{formatDate(date)}</p>
                    )}
                </div>
            </div>
        );
    };
    
    const CandidateTimeline = ({ candidate }) => {
        if (!candidate) return null;
    
        const steps = [
            { id: 'created', label: 'Candidato Creado', date: candidate.created_at, isCompleted: !!candidate.created_at },
            { id: 'invited', label: 'Invitado a Entrevista', date: candidate.invited_at, isCompleted: !!candidate.invited_at },
            { id: 'interviewed', label: 'Entrevistado', date: candidate.interviewed_at, isCompleted: !!candidate.interviewed_at },
            { id: 'offered', label: 'Oferta Realizada', date: candidate.offered_at, isCompleted: !!candidate.offered_at },
            { id: 'hired', label: 'Contratado', date: candidate.hired_at, isCompleted: !!candidate.hired_at },
        ];
    
        return (
            <div>
                {steps.map((step, index) => (
                    <TimelineItem 
                        key={step.id}
                        step={step.label}
                        date={step.date}
                        isCompleted={step.isCompleted}
                        isLast={index === steps.length - 1}
                    />
                ))}
            </div>
        );
    };
    
    export default CandidateTimeline;