import React from 'react';
import {
	Toast,
	ToastClose,
	ToastDescription,
	ToastProvider,
	ToastTitle,
	ToastViewport,
} from '@/components/ui/toast';
import { useToast } from '@/components/ui/use-toast';
import { CheckCircle } from 'lucide-react';

export function Toaster() {
	const { toasts } = useToast();

	return (
		<ToastProvider>
			{toasts.map(({ id, title, description, action, variant, ...props }) => {
				return (
					<Toast key={id} variant={variant} {...props}>
                        <div className="flex items-center gap-3">
                            {variant === 'success' && <CheckCircle className="h-6 w-6 text-[#22C55E]" />}
						    <div className="grid gap-1">
							    {title && <ToastTitle>{title}</ToastTitle>}
							    {description && (
								    <ToastDescription>{description}</ToastDescription>
							    )}
						    </div>
                        </div>
						{action}
						<ToastClose />
					</Toast>
				);
			})}
			<ToastViewport />
		</ToastProvider>
	);
}