import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from "@/components/ui/use-toast";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertCircle, CheckCircle, Loader2, KeyRound, Save, Info } from 'lucide-react';

const ApiKeyManager = () => {
    const { toast } = useToast();
    const { user } = useAuth();
    const [apiKey, setApiKey] = useState('');
    const [isConfigured, setIsConfigured] = useState(false);
    const [keySource, setKeySource] = useState('none');
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const adminEmail = 'ing.miguelarroyo@gmail.com';

    const fetchKeyStatus = async () => {
        setIsLoading(true);
        try {
            const { data, error } = await supabase.functions.invoke('get-effective-openai-key-status');
            if (error) throw error;
            setIsConfigured(data.isConfigured);
            setKeySource(data.source);
        } catch (error) {
            console.error("No se pudo verificar el estado de la clave:", error.message);
            setIsConfigured(false);
            setKeySource('none');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchKeyStatus();
    }, []);

    const handleSaveKey = async () => {
        if (!apiKey) {
            toast({ variant: 'destructive', title: 'Error', description: 'El campo de la clave de API no puede estar vacío.' });
            return;
        }
        setIsSaving(true);
        try {
            const { data, error } = await supabase.functions.invoke('set-openai-key-override', {
                body: { key: apiKey },
            });

            if (error) throw error;

            toast({ variant: 'success', title: 'Éxito', description: data.message });
            setApiKey('');
            await fetchKeyStatus(); // Refresh status after saving
        } catch (error) {
            const errorMessage = error.body ? JSON.parse(error.body).error : error.message;
            toast({ variant: 'destructive', title: 'Error al guardar', description: errorMessage });
        } finally {
            setIsSaving(false);
        }
    };

    const renderStatus = () => {
        if (isLoading) {
            return <p className="text-sm text-stone-400 flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" />Verificando estado...</p>;
        }
        if (isConfigured) {
            return (
                <div className="flex items-center gap-2 text-green-400">
                    <CheckCircle className="h-5 w-5" />
                    <p className="font-medium">
                        Clave de API activa
                        <span className="text-stone-400 font-normal ml-2">({keySource === 'override' ? 'Personalizada' : 'Sistema'})</span>
                    </p>
                </div>
            );
        }
        return (
            <div className="flex items-center gap-2 text-yellow-400">
                <AlertCircle className="h-5 w-5" />
                <p className="font-medium">Clave de API no configurada</p>
            </div>
        );
    };

    if (user?.email !== adminEmail) {
        return (
            <div className="flex items-start gap-4 p-4 rounded-lg bg-stone-900/50 border border-stone-800">
                <Info className="h-6 w-6 text-amber-400 mt-1" />
                <div>
                    <h3 className="font-semibold text-stone-100">Integración con OpenAI</h3>
                    <p className="text-sm text-stone-400 mt-1">La evaluación de candidatos por IA está gestionada por el administrador.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6 p-4 rounded-lg bg-stone-900/50 border border-stone-800">
            <div className="flex-shrink-0">
                <KeyRound className="h-8 w-8 text-amber-400" />
            </div>
            <div className="flex-grow">
                <h3 className="font-semibold text-stone-100">OpenAI API Key (Override)</h3>
                <p className="text-sm text-stone-400 mt-1">Define una clave personalizada que reemplazará la del sistema.</p>
            </div>
            <div className="w-full sm:w-auto sm:min-w-[400px] space-y-3">
                <div className="flex items-center justify-center p-3 rounded-md bg-stone-800 border border-stone-700">
                    {renderStatus()}
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                    <Label htmlFor="openai-api-key" className="sr-only">OpenAI API Key</Label>
                    <Input 
                        id="openai-api-key" 
                        type="password"
                        placeholder="Introduce clave para anular la del sistema (sk-...)" 
                        className="bg-stone-800 border-stone-700 placeholder:text-stone-500 flex-grow"
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                    />
                    <Button onClick={handleSaveKey} disabled={isSaving}>
                        {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                        <span className="ml-2">Guardar</span>
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default ApiKeyManager;