import React, { createContext, useContext, useMemo, useState, useEffect } from 'react';
import { useCandidates } from '@/contexts/CandidateContext';
import { supabase } from '@/lib/customSupabaseClient';
import { format } from 'date-fns';

const DashboardContext = createContext();

export const useDashboard = () => {
  return useContext(DashboardContext);
};

export const DashboardProvider = ({ children }) => {
  const { candidates, loading: candidatesLoading } = useCandidates();
  const [analyticsData, setAnalyticsData] = useState({ weekly: [] });
  const [analyticsLoading, setAnalyticsLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
        setAnalyticsLoading(true);
        try {
            const { data, error } = await supabase.from('vw_recruiting_funnel').select('week, total_applications');
            if (error) throw error;
            setAnalyticsData({
                weekly: data.map(d => ({...d, week: format(new Date(d.week), 'MMM dd')}))
            });
        } catch (error) {
            console.error("Error fetching weekly analytics:", error);
        } finally {
            setAnalyticsLoading(false);
        }
    };
    fetchAnalytics();
  }, []);

  const dashboardData = useMemo(() => {
    if (candidatesLoading || analyticsLoading) {
      return { loading: true };
    }

    const evaluatedCandidates = candidates.filter(c => c.evaluacion_estado === 'listo');
    const aptCandidates = evaluatedCandidates.filter(c => ['CONTRATAR', 'ENTREVISTAR'].includes(c.recomendacion));

    const avgIaScore = evaluatedCandidates.length > 0 ? Math.round(evaluatedCandidates.reduce((acc, c) => acc + (c.puntaje_total || 0), 0) / evaluatedCandidates.length) : 0;

    const toHireCount = candidates.filter(c => c.recomendacion === 'CONTRATAR' && c.recruiter_status !== 'Contratado').length;
    
    const totalPostulados = candidates.length;
    const contratadosCount = candidates.filter(c => c.recruiter_status === 'Contratado').length;
    const hiringRate = totalPostulados > 0 ? ((contratadosCount / totalPostulados) * 100).toFixed(1) : 0;

    const valueAverages = {
      'Servicio': evaluatedCandidates.length > 0 ? Math.round(evaluatedCandidates.reduce((a, b) => a + (b.p_servicio || 0), 0) / evaluatedCandidates.length) : 0,
      'Palabra': evaluatedCandidates.length > 0 ? Math.round(evaluatedCandidates.reduce((a, b) => a + (b.tener_palabra || 0), 0) / evaluatedCandidates.length) : 0,
      'Impacto': evaluatedCandidates.length > 0 ? Math.round(evaluatedCandidates.reduce((a, b) => a + (b.impacto_positivo || 0), 0) / evaluatedCandidates.length) : 0,
      'Mejora': evaluatedCandidates.length > 0 ? Math.round(evaluatedCandidates.reduce((a, b) => a + (b.mejora_continua || 0), 0) / evaluatedCandidates.length) : 0,
    };

    const recommendationDistribution = Object.entries(
      candidates.reduce((acc, c) => {
        const rec = c.recomendacion || 'PENDIENTE';
        acc[rec] = (acc[rec] || 0) + 1;
        return acc;
      }, {})
    ).map(([name, value]) => ({ name, value }));

    const topCandidates = [...candidates]
      .filter(c => c.evaluacion_estado === 'listo')
      .sort((a, b) => (b.puntaje_total || 0) - (a.puntaje_total || 0))
      .slice(0, 5);

    const funnel = {
      postulados: totalPostulados,
      iaOk: aptCandidates.length,
      entrevistados: candidates.filter(c => c.interviewed_at).length,
      contratados: contratadosCount,
    };

    return {
      loading: false,
      kpis: {
        totalPostulados,
        hiringRate,
        avgIaScore,
        toHireCount,
      },
      quality: {
        valueAverages,
        recommendationDistribution,
        topCandidates,
      },
      funnel,
      weeklyApplications: analyticsData.weekly,
    };
  }, [candidates, candidatesLoading, analyticsData, analyticsLoading]);

  return (
    <DashboardContext.Provider value={dashboardData}>
      {children}
    </DashboardContext.Provider>
  );
};