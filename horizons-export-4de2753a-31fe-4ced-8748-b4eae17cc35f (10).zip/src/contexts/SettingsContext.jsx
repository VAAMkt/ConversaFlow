import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

const SettingsContext = createContext();

export const useSettings = () => useContext(SettingsContext);

const SETTING_KEYS = [
    'PUBLIC_POST_APPLY_REDIRECT_URL',
    'N8N_CV_EXTRACTION_WEBHOOK_URL'
];

export const SettingsProvider = ({ children }) => {
    const [settings, setSettings] = useState({
        PUBLIC_POST_APPLY_REDIRECT_URL: 'https://kingpapa.co',
        N8N_CV_EXTRACTION_WEBHOOK_URL: ''
    });
    const [loading, setLoading] = useState(true);

    const fetchSettings = useCallback(async () => {
        setLoading(true);
        try {
            const fetchPromises = SETTING_KEYS.map(key => 
                supabase.functions.invoke('get-public-setting', { body: { key_name: key } })
            );
            
            const results = await Promise.allSettled(fetchPromises);
            
            const newSettings = { ...settings };
            results.forEach((result, index) => {
                const key = SETTING_KEYS[index];
                if (result.status === 'fulfilled' && result.value.data && result.value.data.value) {
                    newSettings[key] = result.value.data.value;
                } else if (result.status === 'rejected') {
                    console.error(`Error fetching setting ${key}:`, result.reason.message);
                }
            });
            setSettings(newSettings);

        } catch (error) {
            console.error("Error fetching public settings:", error.message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchSettings();
    }, [fetchSettings]);

    const updateSetting = async (key, value) => {
        try {
            const { error } = await supabase.functions.invoke('set-public-setting', {
                body: { key_name: key, value: value },
            });
            if (error) throw error;
            await fetchSettings(); // Refresh settings after update
            return { success: true };
        } catch (error) {
            console.error(`Error updating setting ${key}:`, error.message);
            return { success: false, error: error.message };
        }
    };

    const value = {
        settings,
        loading,
        updateSetting,
        refreshSettings: fetchSettings,
    };

    return (
        <SettingsContext.Provider value={value}>
            {children}
        </SettingsContext.Provider>
    );
};