import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/customSupabaseClient';
    
    const CandidateContext = createContext();
    
    export const useCandidates = () => {
      return useContext(CandidateContext);
    };
    
    export const CandidateProvider = ({ children }) => {
      const [candidates, setCandidates] = useState([]);
      const [locations, setLocations] = useState([]);
      const [loading, setLoading] = useState(true);
      const [loadingLocations, setLoadingLocations] = useState(true);
    
      const fetchCandidates = useCallback(async () => {
        try {
          setLoading(true);
          const { data, error } = await supabase.from('candidates').select(`*, locations:preferred_location_id (name, vacancies)`).order('created_at', { ascending: false });
          if (error) throw error;
          setCandidates(data);
        } catch (error) {
          console.error("Error fetching candidates:", error.message);
        } finally {
          setLoading(false);
        }
      }, []);
      
      const fetchLocations = useCallback(async () => {
        try {
          setLoadingLocations(true);
          const { data, error } = await supabase.from('locations').select('*').order('ciudad').order('name', { ascending: true });
          if (error) throw error;
          setLocations(data);
        } catch (error) {
          console.error("Error fetching locations:", error.message);
        } finally {
          setLoadingLocations(false);
        }
      }, []);
    
      useEffect(() => {
        const candidateChannel = supabase.channel('custom-all-channel')
          .on('postgres_changes', { event: '*', schema: 'public', table: 'candidates' }, (payload) => {
            fetchCandidates();
          })
          .on('postgres_changes', { event: '*', schema: 'public', table: 'locations' }, (payload) => {
            fetchLocations();
            fetchCandidates(); // Also refresh candidates in case location info changed (e.g. vacancies)
          })
          .subscribe();
          
        fetchCandidates();
        fetchLocations();
    
        return () => {
            supabase.removeChannel(candidateChannel);
        };
      }, [fetchCandidates, fetchLocations]);
    
      const refreshAll = useCallback(() => {
        fetchCandidates();
        fetchLocations();
      }, [fetchCandidates, fetchLocations]);
    
      const addLocation = async (locationData) => {
        const { data, error } = await supabase
          .from('locations')
          .insert([locationData])
          .select();
        if (error) throw error;
        await fetchLocations(); // Explicitly refresh locations after adding
        return data;
      };
    
      const updateLocation = async (id, updatedData) => {
        const { data, error } = await supabase
          .from('locations')
          .update(updatedData)
          .eq('id', id)
          .select()
          .single();
        if (error) throw error;
        await fetchLocations(); // Explicitly refresh locations after updating
        return data;
      };
    
      const deleteLocation = async (id) => {
        const { error } = await supabase
          .from('locations')
          .delete()
          .eq('id', id);
        if (error) throw error;
        await fetchLocations(); // Explicitly refresh locations after deleting
      };
      
      const assignCandidateToLocation = async (candidateId, locationId) => {
        const { error: candidateUpdateError } = await supabase
          .from('candidates')
          .update({ assigned_location_id: locationId, evaluacion_estado: 'contratado', hired_at: new Date().toISOString() })
          .eq('id', candidateId);
    
        if (candidateUpdateError) throw candidateUpdateError;
    
        const { error: vacancyError } = await supabase.rpc('decrement_vacancies', { loc_id: locationId });
        
        if (vacancyError) throw vacancyError;
    
        refreshAll();
      };
    
      const getCandidateById = async (id) => {
        try {
            const { data, error } = await supabase
                .from('candidates')
                .select('*, preferred_location:preferred_location_id(id, name), assigned_location:assigned_location_id(id, name)')
                .eq('id', id)
                .single();
            if (error) throw error;
            return data;
        } catch (error) {
            console.error('Error fetching candidate by id:', error);
            return null;
        }
      };
      
      const getSignedUrl = async (bucket, path) => {
        if (!path || typeof path !== 'string' || path.trim() === '') {
            console.warn("getSignedUrl called with invalid path:", path);
            return null;
        }
        
        try {
            const { data, error } = await supabase
              .storage
              .from(bucket)
              .createSignedUrl(path, 600); // 10 minutes
              
            if(error) {
              console.error(`Error creating signed URL for path '${path}' in bucket '${bucket}':`, error);
              return null;
            }
            return data.signedUrl;
        } catch (e) {
            console.error("Exception in getSignedUrl:", e);
            return null;
        }
      };
    
    
      const value = {
        candidates,
        locations,
        loading,
        loadingLocations,
        addCandidate: refreshAll,
        getCandidateById,
        getSignedUrl,
        refreshCandidates: fetchCandidates,
        addLocation,
        updateLocation,
        deleteLocation,
        assignCandidateToLocation,
        refreshLocations: fetchLocations,
      };
    
      return (
        <CandidateContext.Provider value={value}>
          {children}
        </CandidateContext.Provider>
      );
    };