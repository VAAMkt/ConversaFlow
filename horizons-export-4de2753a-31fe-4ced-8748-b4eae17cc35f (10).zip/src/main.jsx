import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { BrowserRouter } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';
import { ErrorBoundary } from 'react-error-boundary';
import { Button } from '@/components/ui/button';

const ErrorFallback = ({ error, resetErrorBoundary }) => {
  console.error("Error de renderizado:", error);
  return (
    <div className="flex flex-col justify-center items-center h-screen bg-background text-foreground" role="alert">
      <h2 className="text-2xl font-bold text-destructive mb-4">Algo salió mal</h2>
      <p className="mb-6">No se pudo cargar la aplicación. Por favor, inténtalo de nuevo.</p>
      <Button onClick={resetErrorBoundary}>Reintentar</Button>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary FallbackComponent={ErrorFallback} onReset={() => window.location.reload()}>
      <HelmetProvider>
        <BrowserRouter>
          <AuthProvider>
            <App />
          </AuthProvider>
        </BrowserRouter>
      </HelmetProvider>
    </ErrorBoundary>
  </React.StrictMode>
);